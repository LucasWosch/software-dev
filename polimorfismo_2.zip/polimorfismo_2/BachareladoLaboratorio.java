package polimorfismo_2;

public class BachareladoLaboratorio extends Curso{

	public double custolab;

	@Override
	public double custoCurso() {
		return super.custoCurso() + custolab;
	}
	
}
