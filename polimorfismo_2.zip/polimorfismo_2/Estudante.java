package polimorfismo_2;

import java.util.ArrayList;

public class Estudante {

	public String matricula;
	public String cpf;
	public String nome;
	public String email;
	public ArrayList<InterCurso> cursos;
	
}
