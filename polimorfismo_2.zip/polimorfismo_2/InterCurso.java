package polimorfismo_2;

public interface InterCurso {

	
	public double custoCurso();
	
	public String getName();
}
