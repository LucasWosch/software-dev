package polimorfismo_2;

public class Bacharelado extends Curso{
	
}
