package exercicio_lista_objetos;

public class consumidor {
	public static void main(String[] args) {
		
		Livro livro;
		Estante estante			= new Estante();
		livro 					= new Livro();
		
		livro.Titulo 			= "Biblia";
		livro.Autor 			= "Diversos";
		livro.AnoPublicacao 	= "0";

		estante.Prateleira.add(livro);
		

		livro 					= new Livro();
		livro.Titulo 			= "Alcorão";
		livro.Autor 			= "Diversos";
		livro.AnoPublicacao 	= "0";
		
		estante.Prateleira.add(livro);
		

		livro 					= new Livro();
		livro.Titulo 			= "Torá";
		livro.Autor 			= "Diversos";
		livro.AnoPublicacao 	= "o";
		
		estante.Prateleira.add(livro);
		
		System.out.println(estante.ListarLivros());

		
	}
}
