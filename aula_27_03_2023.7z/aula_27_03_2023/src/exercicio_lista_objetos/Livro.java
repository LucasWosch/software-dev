package exercicio_lista_objetos;

public class Livro {
	
	public String Titulo, Autor, AnoPublicacao;
	
}
