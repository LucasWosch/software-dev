package exercicio_lista_objetos;
import java.util.ArrayList;

public class Estante {

	public ArrayList<Livro> Prateleira = new ArrayList<Livro>();
	
	public String ListarLivros()
	{
		String titulos = "";
		for(int countLivros = 0; countLivros < this.Prateleira.size();countLivros++) {
			titulos += " " + this.Prateleira.get(countLivros).Titulo;
		}
		return(titulos);
	}

}
