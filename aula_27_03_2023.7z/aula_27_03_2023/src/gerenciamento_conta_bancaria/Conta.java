package gerenciamento_conta_bancaria;

public class Conta {
	String Numero, Tipo;
	Double Saldo;
	
	Conta(String numero, String tipo, Double saldo){
		
		this.Numero = numero;
		this.Tipo	= tipo;
		this.Saldo 	= saldo;
		
	}
	
	public void deposito(float valor) {
		this.Saldo += valor;
	}
	
	public void saque(float valor) {
		if(this.Saldo >= valor) {
			this.Saldo -= valor;
		}
		else{
			System.out.println("Saldo insuficiênte.");
		}
	}
	
	
}