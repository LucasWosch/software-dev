package gerenciamento_conta_bancaria;

import java.util.ArrayList;
import java.util.Random;

public class Cliente {

	String CPF, Nome, Email;
	ArrayList<Conta> contas = new ArrayList<Conta>();
	
	public String ListarContas()
	{
		String dados = "";
		for(int countConta = 0; countConta < this.contas.size();countConta++) {
			dados += " " + this.contas.get(countConta).Numero + " - " + this.contas.get(countConta).Tipo + ": R$" + this.contas.get(countConta).Saldo + "\n";
		}
		return(dados);
	}

	public boolean ExisteConta(String tipoConta) {

		if(this.contas.size() > 0) {
			for(int countConta = 0; countConta < this.contas.size();countConta++) {
				if(this.contas.get(countConta).Tipo.equals(tipoConta)) {
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean CriaConta(String tipoConta) {
		
		String[] tiposConta = {"", "Conta Corrente", "Conta Poupança"};
		
		if(!ExisteConta(tiposConta[Integer.parseInt(tipoConta)])) {
			Random random = new Random();
			try{
				Conta conta	= new Conta(Integer.toString(random.nextInt(99999)), tiposConta[Integer.parseInt(tipoConta)], 0.00);
				this.contas.add(conta);
			}
			catch(Exception e){
				System.out.println(e);
				return false;
			}
			return true;
		}
		return false;
	}
	
	
	
	
	
	
	
	
}
