package gerenciamento_conta_bancaria;

import java.io.IOException;
import java.util.Scanner;

public class cosumidorBanco {

	public static void main(String[] args) throws IOException {
		
		
		Scanner teclado 		= new Scanner(System.in);
		Cliente cliente;
		
		String opcao;
		String opcaoMenu 		= "";
		
		cliente 				= new Cliente();

		System.out.println("=============================================================");
		System.out.println("                            BANCO                            ");
		System.out.println("=============================================================");
		
		System.out.print("Nome: ");
		cliente.Nome			= teclado.nextLine();
		System.out.print("Email: ");
		cliente.Email			= teclado.nextLine();
		System.out.print("CPF: ");
		cliente.CPF				= teclado.nextLine();
		
		while(!opcaoMenu.equals("5")) {
			System.out.println("=============================================================");
			System.out.println("1 - Criar Conta");
			System.out.println("2 - Ver Saldo");
			System.out.println("3 - Sacar");
			System.out.println("4 - Depositar");
			System.out.println("5 - Sair");
			System.out.println("-------------------------------------------------------------");
			System.out.print("Digite a opção desejada: ");
			
			opcaoMenu 			= teclado.nextLine();
			
			if (opcaoMenu.equals("1")) {
				System.out.println("=============================================================");
				System.out.println("1 - Conta Corrente");
				System.out.println("2 - Conta Poupança");
				System.out.println("-------------------------------------------------------------");
				System.out.print("Digite a opção desejada: ");
				opcao 		 	= teclado.nextLine();
				
				if(cliente.CriaConta(opcao)) {
					System.out.println("=============================================================");
					System.out.println("                        CONTA CRIADA!                        ");
					System.out.println("=============================================================");
					System.out.println("Pressione Enter para continuar...");
					opcaoMenu	= teclado.nextLine();
				}
				else {
					System.out.println("=============================================================");
					System.out.println("               NÃO FOI POSSÍVEL CRIAR A CONTA                ");
					System.out.println("=============================================================");
					System.out.println("Pressione Enter para continuar...");
					opcaoMenu	= teclado.nextLine();
				}
			}
			else if(opcaoMenu.equals("2")) {
				System.out.println(cliente.ListarContas());
			}
		}
		
		
		
	}

}
