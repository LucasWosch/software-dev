package coisas_e_coisas;

import java.sql.*;

public class Cliente {

	public String cpf, nome, email, telefone, endereco;
	public int tipo_user = 1;
	
//	public Cliente(String cpf, String nome, String email, String telefone, String endereco) {
//		this.cpf 		= cpf;
//		this.nome 		= nome;
//		this.email 		= email;
//		this.telefone 	= telefone;
//		this.endereco 	= endereco;
//	}
	
	public boolean save() {
		Connection conn = Banco.conectar();
		
		String sql;
		sql = "INSERT INTO usuarios VALUES(?,?,?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ps.setString(1, null);
			ps.setString(2, this.cpf);
			ps.setString(3, this.nome);
			ps.setString(4, this.email);	
			ps.setString(5, this.telefone);	
			ps.setString(6, this.endereco);	
			ps.setString(7, "2");	
			ps.setString(8, "1");	
			
			int retorno 			= ps.executeUpdate();
		
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}

}
