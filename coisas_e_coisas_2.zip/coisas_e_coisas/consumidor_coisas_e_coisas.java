package coisas_e_coisas;

import java.util.Scanner;

public class consumidor_coisas_e_coisas {

	public static void main(String[] args) {

		String opcaoMenu 		= "";
		String opcaoSubMenu		= "";
		Scanner teclado 		= new Scanner(System.in);
		Cliente cliente;
		
		
		while(!opcaoMenu.equals("5")) {
		System.out.println("=====================================================");
		System.out.println("                   COISAS E COISAS                   ");
		System.out.println("=====================================================");
		
		System.out.println("1 - Clientes");
		System.out.println("2 - Prestadores");
		System.out.println("3 - Tipos Serviços");
		System.out.println("4 - Serviços");
		System.out.println("5 - Sair");

		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");

		opcaoMenu 				= teclado.nextLine();
		
		if(opcaoMenu.equals("1")) {
			System.out.println("=====================================================");
			System.out.println("                   COISAS E COISAS                   ");
			System.out.println("=====================================================");
			
			System.out.println("1 - Cadastrar Cliente");
			System.out.println("2 - Visualizar Clientes");
			System.out.println("3 - Procurar Cliente");
			System.out.println("0 - Voltar");

			System.out.println("=====================================================");
			System.out.print("Digite a opção desejada: ");

			opcaoSubMenu 		= teclado.nextLine();
			
			if(opcaoSubMenu.equals("1")) {
				
				cliente = new Cliente();
				
				System.out.println("=====================================================");
				System.out.println("                   COISAS E COISAS                   ");
				System.out.println("=====================================================");
				
				System.out.print("Digite o CPF do cliente: ");
				cliente.cpf 		= teclado.nextLine();
				System.out.print("Digite o Nome do cliente: ");
				cliente.nome 		= teclado.nextLine();
				System.out.print("Digite o E-mail do cliente: ");
				cliente.email 		= teclado.nextLine();
				System.out.print("Digite o Telefone do cliente: ");
				cliente.telefone	= teclado.nextLine();
				System.out.print("Digite o Endereço do cliente: ");
				cliente.endereco	= teclado.nextLine();
				
				if(cliente.save()) {
					System.out.println("=====================================================");
					System.out.println("           CLIENTE CADASTRADO COM SUCESSO!           ");
					System.out.println("=====================================================");
					System.out.println("Pressione Enter para continuar...");
					
					opcaoMenu 		= teclado.nextLine();
				}
			}
		}
		else if(opcaoMenu.equals("2")) {
			
		}
		
//		Cliente cliente 	= new Cliente();
//		
//		cliente.cpf 		= "123.456.789-12";
//		cliente.nome 		= "João";
//		cliente.email		= "joao@email.com";
//		cliente.telefone	= "(11)11111-1111";
//		cliente.endereco	= "Rua Teste";
//		
//		cliente.save();
//		
//		
//		Prestador prestador = new Prestador();
//		
//		prestador.cpf		= "234.567.890-12";
//		prestador.nome		= "Carlos";
//		prestador.email		= "carlos@email.com";
//		prestador.telefone	= "(11)11111-1111";
//		prestador.endereco	= "Rua Teste 2";
//		
//		prestador.save();
		
		}
		
		
		
	

	}

}
