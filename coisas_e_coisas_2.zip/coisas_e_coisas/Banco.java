package coisas_e_coisas;

import java.sql.*;

public class Banco {
	
	static String url 		= "jdbc:mysql://localhost:3306/coisas_e_coisas";
	static String user 	= "root";
	static String password	= "positivo";
	static Connection conn;
	
	
	private Banco() {
		
	}
	

	static Connection conectar() {
		if(conn == null) {			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				conn			= DriverManager.getConnection(url, user, password);
			}
			catch(Exception e) {
				System.out.println(e);
			}
		}
		return conn;
	}
}

