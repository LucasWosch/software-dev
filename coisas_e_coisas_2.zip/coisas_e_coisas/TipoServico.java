package coisas_e_coisas;

public class TipoServico {
	
	public String nome, servico;
	public int status;
	
}
