package coisas_e_coisas;

public class Servico {

	public Cliente cliente;
	public Prestador prestador;
	
}
