package exercicio_lista_objetos;

public class consumidor {
	public static void main(String[] args) {
		
		Livro livro1 			= new Livro();
		Estante estante			= new Estante();
		
		livro1.Titulo 			= "Biblia";
		livro1.Autor 			= "Diversos";
		livro1.AnoPublicacao 	= "0";

		estante.Prateleira.add(livro1);
		

		Livro livro2 			= new Livro();
		livro2.Titulo 			= "Alcorão";
		livro2.Autor 			= "Diversos";
		livro2.AnoPublicacao 	= "0";
		
		estante.Prateleira.add(livro2);
		

		Livro livro3 			= new Livro();
		livro3.Titulo 			= "Torá";
		livro3.Autor 			= "Diversos";
		livro3.AnoPublicacao 	= "o";
		
		estante.Prateleira.add(livro3);
		
		for(int countLivros = 0; countLivros < estante.Prateleira.size();countLivros++) {
			System.out.println(estante.Prateleira.get(countLivros).Titulo);
		}

		
	}
}
