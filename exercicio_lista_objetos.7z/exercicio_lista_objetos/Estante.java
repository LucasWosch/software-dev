package exercicio_lista_objetos;
import java.util.ArrayList;

public class Estante {

	public ArrayList<Livro> Prateleira = new ArrayList<Livro>();

}
