package coisas_e_coisas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Servico {

	public int id;
	public Cliente cliente;
	public Prestador prestador;
	public TipoServico tipoServico;
	public String dataServico;
	public double valorServico;
	
	private Servico(int id, Cliente cliente, Prestador prestador, TipoServico tipoServico, String dataServico, double valorServico) {
		this.id = id;
		this.cliente = cliente;
		this.prestador = prestador;
		this.tipoServico = tipoServico;
		this.dataServico = dataServico;
		this.valorServico = valorServico;
	}
	
	public Servico() {}

	public int save() {
		
		Connection conn = Banco.conectar();
		
		String sql;
		sql = "INSERT INTO servicos VALUES(?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ps.setString(1, null);
			ps.setInt(2, this.cliente.id);
			ps.setInt(3, this.prestador.id);
			ps.setInt(4, this.tipoServico.id);
			ps.setString(5, this.dataServico);
			ps.setDouble(6, this.valorServico);
			
			int retorno 			= ps.executeUpdate();
			return 1;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
	
	public ArrayList<Servico> find_all(){
		
		Connection conn 				= Banco.conectar();
		String sql;
		ArrayList<Servico> allServicos 	= new ArrayList<Servico>();
		Cliente cliente 				= new Cliente();
		Prestador prestador 			= new Prestador();
		TipoServico tipoServico 		= new TipoServico();

		sql = "SELECT S.*, C.cpf AS cpf_cliente, P.cpf AS cpf_prestador, TP.nome_servico FROM servicos S INNER JOIN usuarios C ON S.fk_cliente = C.id INNER JOIN usuarios P ON S.fk_prestador = P.id INNER JOIN tipo_servicos TP ON S.fk_servico = TP.id";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs 				= ps.executeQuery();

            while (rs.next()) {
            	cliente.find_one(rs.getString("cpf_cliente"));
            	prestador.find_one(rs.getString("cpf_prestador"));
            	tipoServico.find_one(rs.getString("nome_servico"));
            	allServicos.add(new Servico(rs.getInt("id"), cliente, prestador, tipoServico, rs.getString("data"), rs.getDouble("valor")));
            }
            return allServicos;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int delete() {

		Connection conn = Banco.conectar();
		String sql;
		
		sql = "DELETE FROM servicos WHERE id = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, this.id);
			ps.executeUpdate();
            return 1;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
