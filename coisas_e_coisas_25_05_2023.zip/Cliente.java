package coisas_e_coisas;

public class Cliente extends Pessoa {
	
	public Cliente() {		
		this.tipo_user 		= "1";
	}
}
