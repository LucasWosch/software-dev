/**
 * 
 */
/**
 * @author Aluno
 *
 */
module FactoryMethod {
}