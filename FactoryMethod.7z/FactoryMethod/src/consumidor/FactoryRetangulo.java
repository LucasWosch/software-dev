package consumidor;

public class FactoryRetangulo implements iFactoryFormas{
	
	public iForma criarForma()
	{
		return new Retangulo();
	}
	
}
