package consumidor;

public class Circulo implements iForma{

	public void desenhar()
	{
		System.out.println("Circulo desenhado.");
	}
}
