package consumidor;

public interface iFactoryFormas {
	public iForma criarForma();
}
