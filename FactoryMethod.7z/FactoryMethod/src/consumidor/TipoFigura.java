package consumidor;

public enum TipoFigura {
	FactoryCirculo("Circulo"),
	FactoryRetangulo("Regantulo");
	
	private String descricao;

	TipoFigura(String descricao)
	{
		this.descricao = descricao;
	}
	
	public String getDescricao()
	{
		return descricao;
	}
	

    public String getPath() {
    	if(this.getDescricao() == "Circulo")
    	{
    		return "consumidor.FactoryRetanglo";
    	}
    	else
    	{
    		return "consumidor.FactoryRetanglo";
    	}
    }
	
	
}
