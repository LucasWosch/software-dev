package consumidor;

public class Retangulo implements iForma{

	public void desenhar()
	{
		System.out.println("Retangulo desenhado.");
	}
}
