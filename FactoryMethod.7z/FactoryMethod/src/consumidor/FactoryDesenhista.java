package consumidor;
import java.lang.reflect.InvocationTargetException;

public class FactoryDesenhista{
	
	public void desenha(TipoFigura tipoFigura) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
	    iForma forma;
	    iFactoryFormas factoryForma = null;
	    System.out.println(tipoFigura.name());
	    
	    try {
	        Class<?> clazz = Class.forName(tipoFigura.getPath()); 
	        
	        factoryForma = (iFactoryFormas) clazz.getDeclaredConstructor().newInstance();
	        
	        forma = factoryForma.criarForma();
	        forma.desenhar();
	    } catch (ClassNotFoundException e) {
	        System.out.println("Classe não encontrada: " + e.getMessage());
	    } 
	}

}
