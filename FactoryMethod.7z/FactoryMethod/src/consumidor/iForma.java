package consumidor;

public interface iForma {
	public void desenhar();
}
