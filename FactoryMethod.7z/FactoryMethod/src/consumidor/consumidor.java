package consumidor;


import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

public class consumidor {

	public static void main(String[] args) {
		
		int index = 1;
		
		FactoryCirculo circulo = new FactoryCirculo();
		System.out.println(circulo.getClass());
		
		for (TipoFigura figura : TipoFigura.values()) {
            System.out.println(index + " - " + figura.getDescricao());
            index += 1;
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o número da sua escolha: ");
        int escolha = scanner.nextInt();
        
        
        FactoryDesenhista desenhista	= new FactoryDesenhista();
        try {
			desenhista.desenha(TipoFigura.values()[escolha - 1]);
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
