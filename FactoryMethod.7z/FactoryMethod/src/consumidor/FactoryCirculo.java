package consumidor;

public class FactoryCirculo implements iFactoryFormas{
	
	public iForma criarForma()
	{
		return new Circulo();
	}
	
}
