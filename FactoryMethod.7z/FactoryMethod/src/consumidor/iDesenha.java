package consumidor;

public interface iDesenha {
	public void desenha(iFactoryFormas factoryFormas);
}
