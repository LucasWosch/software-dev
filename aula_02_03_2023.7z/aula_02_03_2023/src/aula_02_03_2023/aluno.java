package aula_02_03_2023;

public class aluno {

	String nome, CPF, email, celular;
	
	
}
