package aula_02_03_2023;

public class teste_aluno {

	public static void main(String[] args) {
		
		// Criar um objeto da classe aluno
		
		aluno Estudante = new aluno();
		
		Estudante.nome 		= "Lucas";
		Estudante.CPF 		= "123456789-12";
		Estudante.email		= "lucas@gmail.com";
		Estudante.celular	= "(41) 12877-3787";
		
		System.out.println(Estudante.nome);
		System.out.println(Estudante.email);
		System.out.println(Estudante.celular);
		
	}

}
