package polimorfismo;

public class Pedagio {
	
	
	public double Cobrar(Veiculo veiculo) {
		
		double tarifa = 1.50;
		
		double valor_total = tarifa * veiculo.getEixos();
		return valor_total;
	}
}
