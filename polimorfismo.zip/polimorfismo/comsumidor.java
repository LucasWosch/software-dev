package polimorfismo;

public class comsumidor {

	public static void main(String[] args) {

		Moto moto = new Moto();
		moto.combustivel = "alcool";
		
		Carro carro = new Carro();
		carro.combustivel = "gasolina";
		
		Caminhao caminhao = new Caminhao();
		Pedagio pedagio = new Pedagio();
		
		
		System.out.println(pedagio.Cobrar(carro));
		
		
	}

}
