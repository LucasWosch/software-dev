package polimorfismo;

public class Moto implements Veiculo{

	public String combustivel;
	
	public int getEixos() 
	{
		return 0;
	}
	
}
