package polimorfismo;

public class consumidor {

	public static void main(String[] args) {
	}

}
