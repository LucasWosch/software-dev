package polimorfismo;

public interface Veiculo {

	
	public int getEixos();
}
