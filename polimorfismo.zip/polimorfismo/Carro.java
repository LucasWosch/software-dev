package polimorfismo;

public class Carro implements Veiculo{
	public String combustivel;
	private int eixos = 2;
	
	public int getEixos() 
	{
		return this.eixos;
	}
	
}
