package aula_10_04_2023;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ler_csv {

	public static void main(String[] args){

		try {
			FileInputStream stream 		= new FileInputStream("C:\\Users\\Aluno\\Documents\\teste\\teste.csv");
			InputStreamReader reader 	= new InputStreamReader(stream);
			BufferedReader br 			= new BufferedReader(reader);
			String linha = "";
			while(linha != null) {
				System.out.println(linha);
				linha = br.readLine();
			}
			br.close();
			reader.close();
			stream.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

}
