package aula_10_04_2023;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class teste {

	public static void main(String[] args)
	{	
		Scanner teclado = new Scanner(System.in);
		String frase = " ";
		
		try {
			System.out.println("Digite o que deseja salvar, para sair aperte duas vezes o enter: ");
			while(!frase.equals("")){
				FileWriter arq = new FileWriter("C:\\Users\\Aluno\\Documents\\teste\\texto.txt", true);
				frase 		= teclado.nextLine();
				if(!frase.equals("")) {					
					arq.write(frase + "\n");
					
					arq.flush();
					arq.close();
				}
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Conteudo digitado:");
		System.out.println("-----------------------------------------------------");
		
		FileInputStream stream;
		try {
			stream = new FileInputStream("C:\\Users\\Aluno\\Documents\\teste\\texto.txt");
			InputStreamReader reader = new InputStreamReader(stream);
			BufferedReader br = new BufferedReader(reader);
			String linha;
			try {
				linha = br.readLine();
				while(linha != null) {
					System.out.println(linha);
					linha = br.readLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	
}
