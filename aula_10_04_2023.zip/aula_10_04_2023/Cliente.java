package aula_10_04_2023;

import java.io.FileWriter;
import java.io.IOException;

public class Cliente {

	public String nome;
	public String cpf;
	public String mail;
	
	public void salvar() {
		FileWriter arq;
		try {
			String separador = ";";
			arq = new FileWriter("C:\\Users\\Aluno\\Documents\\teste\\cliente.csv", true);
			arq.write(this.cpf + separador + this.nome + separador + this.mail + "\n");
			arq.flush();
			arq.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
