package aula_10_04_2023;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class consumidor_grava_cliente {

	public static void main(String[] args) {
		Scanner teclado 	= new Scanner(System.in);
		String frase 		= "";
		String option 		= "";
		Cliente cliente;
		
		while(!option.equals("0")){
			System.out.println("Digite o cpf, nome e e-mail do cliente: ");
			cliente 	= new Cliente();
			
			System.out.print("Digite o CPF: ");
			frase 			= teclado.nextLine(); 
			cliente.cpf 	= frase;
			
			System.out.print("Digite o nome: ");
			frase 			= teclado.nextLine(); 
			cliente.nome 	= frase;
			
			System.out.print("Digite o e-mail: ");
			frase 			= teclado.nextLine(); 
			cliente.mail	= frase;
			
			cliente.salvar();
			System.out.println("Deseja sair do sistema? (0 para sair)");
			option 			= teclado.nextLine();
		}
	}

}
