package aula_10_04_2023;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class ler_csv2 {
	
	public static void main(String[] args) {	
		
		FileReader reader;
		Cliente cliente 		= new Cliente();
		
		try {
			reader 				= new FileReader("C:\\Users\\Aluno\\Documents\\teste\\teste.csv");
			BufferedReader br 	= new BufferedReader(reader);
			String linha 		= br.readLine();
			linha 				= br.readLine();
			
			cliente.cpf 		= linha.split(";")[0];
			cliente.nome 		= linha.split(";")[1];
			cliente.mail 		= linha.split(";")[2];

			cliente.salvar();
			
			System.out.println(cliente.cpf);
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
