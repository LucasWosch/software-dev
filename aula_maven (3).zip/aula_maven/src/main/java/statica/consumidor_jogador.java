package statica;

public class consumidor_jogador {

	public static void main(String[] args) {
		jogador j1 = jogador.getInstance();
		j1.id 	= 1; 
		j1.nome = "TESTE";
		System.out.println(j1.nome);
		
		jogador j2 = jogador.getInstance();
		System.out.println(j2.nome);
		
	}

}
