package statica;

public class Teste {

	public 	int var_publica;
	private int var_private;
	static 	int var_statica;
	
}
