package statica;

public class consumidor_teste {

	public static void main(String[] args) {
		
		Teste t1 = new Teste();
		
		t1.var_publica = 13;
		t1.var_statica = 5;
		
		System.out.println("T1 - PUBLICA: "+ t1.var_publica);
		System.out.println("T1 - STATICA: "+ t1.var_statica);
		
		Teste t2 = new Teste();
		
		t2.var_publica = 10;
		
		System.out.println("T2 - PUBLICA: "+ t2.var_publica);
		System.out.println("T2 - STATICA: "+ t2.var_statica);
		
		Teste t3 = new Teste();
		
		t3.var_publica = 12;
		t3.var_statica = 9;
		
		System.out.println("T3 - PUBLICA: "+ t3.var_publica);
		System.out.println("T1 - STATICA: "+ t1.var_statica);
		
		
		

	}

}
