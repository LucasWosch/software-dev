package statica;

public class jogador {

		public int id;
		public String nome;
		static jogador j;
		
		private jogador() {
			
		}
		
		static jogador getInstance() {	
			if(j == null) {				
				j = new jogador();
			}
			return j;
		}
	
}
