import java.util.ArrayList;

public class Banco {
	public int id;
	public String nome_do_banco;
	ArrayList<Cliente> clientes;
}
