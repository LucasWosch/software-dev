package coisas_e_coisas;

import java.util.ArrayList;
import java.util.Scanner;

public class consumidor_coisas_e_coisas {

	public static void main(String[] args) {

		String opcaoMenu 		= "";
		String opcaoSubMenu		= "";
		String opcaoCliente		= "";
		String opcaoPrestador	= "";
		String servicoEscolhido = "";
		String addOtherService 	= ""; 
		Scanner teclado 		= new Scanner(System.in);
		Cliente cliente;
		Prestador prestador;
		TipoServico tipoServico;
		Menu menu				= new Menu();
		
		
		do{
		
			menu.menu_principal();
			opcaoMenu 			= teclado.nextLine();
			
			if(opcaoMenu.equals("1")) {
				System.out.println("=====================================================");
				System.out.println("                   COISAS E COISAS                   ");
				System.out.println("=====================================================");
				
				System.out.println("1 - Cadastrar Cliente");
				System.out.println("2 - Visualizar Cliente");
				System.out.println("3 - Visualizar Clientes");
				System.out.println("4 - Deletar Cliente");
				System.out.println("0 - Voltar");
	
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR CLIENTE
				
				if(opcaoSubMenu.equals("1")) {
					
					cliente = new Cliente();
					
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("===================================2==================");
					
					System.out.print("Digite o CPF do cliente: ");
					cliente.cpf 		= teclado.nextLine();
					System.out.print("Digite o Nome do cliente: ");
					cliente.nome 		= teclado.nextLine();
					System.out.print("Digite o E-mail do cliente: ");
					cliente.email 		= teclado.nextLine();
					System.out.print("Digite o Telefone do cliente: ");
					cliente.telefone	= teclado.nextLine();
					System.out.print("Digite o Endereço do cliente: ");
					cliente.endereco	= teclado.nextLine();
					
					if(cliente.save() > 0) {
						System.out.println("=====================================================");
						System.out.println("           CLIENTE CADASTRADO COM SUCESSO!           ");
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						
						opcaoMenu 		= teclado.nextLine();
					}
				}
				
	//			VISUALIZAR CLIENTE
				
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do cliente: ");
					
					cliente 			= new Cliente();					
					
					if(cliente.find_one(teclado.nextLine()) > 0) {
						System.out.println("=====================================================");
						System.out.println("                 CLIENTE ENCONTRADO!                 ");
						System.out.println("=====================================================");
						System.out.println("Informações de " + cliente.nome + ":");
						System.out.println("CPF: " + cliente.cpf);
						System.out.println("Nome: " + cliente.nome);
						System.out.println("Email: " + cliente.email);
						System.out.println("Telefone: " + cliente.telefone);
						System.out.println("Endereço: " + cliente.endereco);
						System.out.println("-----------------------------------------------------");
						System.out.println("Opções:");
						System.out.println("1 - Deletar Cliente");
						System.out.println("2 - Editar Cliente");
						System.out.println("0 - Voltar");
						System.out.println("=====================================================");
						System.out.print("Digite a opção desejada: ");
			
						opcaoCliente 		= teclado.nextLine();
					}
					
				}
				
			}
			else if(opcaoMenu.equals("2")) {
				System.out.println("=====================================================");
				System.out.println("                   COISAS E COISAS                   ");
				System.out.println("=====================================================");
				
				System.out.println("1 - Cadastrar Prestador");
				System.out.println("2 - Visualizar Prestrador");
				System.out.println("3 - Visualizar Prestadores");
				System.out.println("4 - Deletar Prestador");
				System.out.println("0 - Voltar");
	
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR CLIENTE
				
				if(opcaoSubMenu.equals("1")) {
					
					prestador = new Prestador();
					
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("=====================================================");
					
					System.out.print("Digite o CPF do prestador: ");
					prestador.cpf 		= teclado.nextLine();
					System.out.print("Digite o Nome do prestador: ");
					prestador.nome 		= teclado.nextLine();
					System.out.print("Digite o E-mail do prestador: ");
					prestador.email 	= teclado.nextLine();
					System.out.print("Digite o Telefone do prestador: ");
					prestador.telefone	= teclado.nextLine();
					System.out.print("Digite o Endereço do prestador: ");
					prestador.endereco	= teclado.nextLine();
					
					if(prestador.save() > 0) {
						System.out.println("=====================================================");
						System.out.println("          PRESTADOR CADASTRADO COM SUCESSO!          ");
						System.out.println("=====================================================");
						System.out.println("1 - Vincula-lo em um tipo de serviço");
						System.out.println("0 - Voltar");
						System.out.println("-----------------------------------------------------");
						System.out.print("Digite a opção desejada: ");
						
						opcaoPrestador 	= teclado.nextLine();
						
						if(opcaoPrestador.equals("1")) {

							tipoServico = new TipoServico();
							
							ArrayList<TipoServico> allTiposServicos;
							try {
								allTiposServicos = tipoServico.find_all();
								while(!addOtherService.equals("N")) {									
									if(allTiposServicos.size() > 0) {
										
										for(int countServico = 0; countServico < allTiposServicos.size(); countServico++) {	
											System.out.println("-----------------------------------------------------");
											System.out.println(allTiposServicos.get(countServico).id + " - " + allTiposServicos.get(countServico).nome);		
										}
										
										System.out.println("=====================================================");
										System.out.print("Digite o serviço desejado: ");
										servicoEscolhido	= teclado.nextLine();
										
										System.out.println("=====================================================");
										System.out.print("Deseja adicionar um novo serviço (S/N): ");
										addOtherService		= teclado.nextLine();
										
									}
								}
							}
							catch(Exception e) {
							}
						}
					}
				}
				
			}
			else if(opcaoMenu.equals("3")) {
				menu.cabecalho();
				
				System.out.println("1 - Cadastrar Tipo de Serviço");
				System.out.println("2 - Visualizar Tipo de Serviço");
				System.out.println("3 - Visualizar Prestradores de um Tipo de Serviço");
				System.out.println("4 - Deletar  Tipo de Serviço");
				System.out.println("0 - Voltar");
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR TIPO DE SERVIÇO
				
				if(opcaoSubMenu.equals("1")) {
					
					tipoServico = new TipoServico();
					
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("=====================================================");
					
					System.out.print("Digite o Nome do tipo do serviço: ");
					tipoServico.nome 		= teclado.nextLine();
					System.out.print("Digite a Descrição do tipo do serviço: ");
					tipoServico.desc 		= teclado.nextLine();
					
					if(tipoServico.save() > 0) {
						System.out.println("=====================================================");
						System.out.println("           SERVIÇO CADASTRADO COM SUCESSO!           ");
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						
						opcaoMenu 		= teclado.nextLine();
					}
				}
			}
		
		}while(!opcaoMenu.equals("5"));
		
		
		
	

	}

}
