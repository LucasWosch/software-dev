package coisas_e_coisas;

import java.sql.*;

public class Pessoa {
	
	public String cpf, nome, email, telefone, endereco, tipo_user;
	public int id;
	
	public int save() {
		
		if(this.find_one(this.cpf) == 0){
			Connection conn = Banco.conectar();
			
			String sql;
			sql = "INSERT INTO usuarios VALUES(?,?,?,?,?,?,?,?)";
			
			try {
				PreparedStatement ps 	= conn.prepareStatement(sql);
				ps.setString(1, null);
				ps.setString(2, this.cpf);
				ps.setString(3, this.nome);
				ps.setString(4, this.email);	
				ps.setString(5, this.telefone);	
				ps.setString(6, this.endereco);	
				ps.setString(7, this.tipo_user);	
				ps.setString(8, "1");	
				
				int retorno 			= ps.executeUpdate();
				this.find_one(this.cpf);
				return 1;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			return 2;
		}
		return 0;
		
	}
	
	
	public int find_one(String cpf) {

		Connection conn = Banco.conectar();
		String sql;
		
		sql = "SELECT * FROM usuarios WHERE cpf = ? LIMIT 1";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cpf);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	this.id 		= rs.getInt("id");
                this.cpf 		= rs.getString("cpf");
                this.nome 		= rs.getString("nome");
                this.email 		= rs.getString("email");
                this.telefone 	= rs.getString("telefone");
                this.endereco 	= rs.getString("endereco");
                this.tipo_user	= rs.getString("tipo_user");
            }
            
            return 1;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
		
	}

	
}
