package coisas_e_coisas;

import java.sql.*;
import java.util.ArrayList;

public class Prestador extends Pessoa{
	
	
	public Prestador() {		
		this.tipo_user 		= "2";
	}
	
	public ArrayList<TipoServico> tiposServico;

	public int save_servicos(){
		
		if(tiposServico != null && tiposServico.size() > 0) {
			
			Connection conn = Banco.conectar();
			String sql;
			
			for(int countServicos = 0; countServicos < tiposServico.size(); countServicos++) {	
				sql = "INSERT INTO prestador_servico VALUES(?,?,?)";
				
				try {
					PreparedStatement ps 	= conn.prepareStatement(sql);
					ps.setString(1, null);
					ps.setInt(2, this.id);
					ps.setInt(3, tiposServico.get(countServicos).id);
					
					int retorno 			= ps.executeUpdate();
				
					return retorno;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return 1;
		
	}
	
}
