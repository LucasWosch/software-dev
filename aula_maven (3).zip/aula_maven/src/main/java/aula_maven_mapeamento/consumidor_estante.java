package aula_maven_mapeamento;

public class consumidor_estante {

	public static void main(String[] args) {
		
		Livro livro 			= new Livro();
		Prateleira prateleira 	= new Prateleira();
		Estante estante 		= new Estante();
		
		livro.titulo			= "Vidas Secas";
		livro.autor				= "Graciliano R,";
		livro.edicao 			= "2a. Edição";
		
		prateleira.livros.add(livro);
		
		livro 					= new Livro();
		
		livro.titulo			= "Capitães de Areia";
		livro.autor				= "Jorge A.";
		livro.edicao 			= "1a. Edição";
		
		prateleira.livros.add(livro);
		estante.prateleiras.add(prateleira);
		
		for(int countPrateleiras = 0; countPrateleiras < estante.prateleiras.size(); countPrateleiras++) {
			for(int countLivros = 0; countLivros < estante.prateleiras.get(countPrateleiras).livros.size(); countLivros++) {			
				System.out.println(estante.prateleiras.get(countPrateleiras).livros.get(countLivros).titulo);
			}
		}
		
	}

}
