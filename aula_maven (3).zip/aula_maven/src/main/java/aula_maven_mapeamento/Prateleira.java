package aula_maven_mapeamento;

import java.util.ArrayList;

public class Prateleira {
	
	public ArrayList<Livro> livros = new ArrayList<Livro>();
}
