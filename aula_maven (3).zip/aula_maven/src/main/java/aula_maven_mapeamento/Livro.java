package aula_maven_mapeamento;

public class Livro {

	public String autor, titulo, edicao;
	
}
