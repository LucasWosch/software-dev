
public class Aluno {
	private String nome; 
   private int idade; 
   public Aluno(){} 
   
   public String getnome() { 
      return nome; 
   }
   
   public void setnome(String nome) { 
      this.nome = nome; 
   } 
   
   public int getidade() { 
      return idade; 
   }
   
   public void setidade(int idade) { 
      this.idade = idade; 
   }
   
   public String toString() { 
      return "Estudante [ nome: "+nome+", idade: "+ idade+ " ]"; 
	   }  
}
