package banco_de_dados;

import java.sql.*;

public class exemplo_banco_de_dados {

	public static void main(String[] args) {
		
		Banco banco 				= new Banco();
		Connection conn 			= banco.init();		
		String sql;
		int	id = 0;
		
		
		// EXEMPLO SELECT
		sql 						= "SELECT * FROM clientes";
		
		try {
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ResultSet rs 			= ps.executeQuery();
			while(rs.next()) {
				id 					= rs.getInt("id");
				String cpf 			= rs.getString("cpf");
				String nome 		= rs.getString("nome");
				String email 		= rs.getString("email");
				
				System.out.println(id + " - " + cpf + " - " + nome + " - " + email);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		// EXEMPLO INSERT
		sql = "INSERT INTO clientes VALUES(?,?,?,?)";
		
		try {
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ps.setInt(1, id + 1);
			ps.setString(2, "101010");
			ps.setString(3, "Sergio Malandro");
			ps.setString(4, "sergiom@mail.com");	
			
			int retorno 			= ps.executeUpdate();
				
			System.out.println(retorno);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// EXEMPLO UPDATE
		
		sql = "UPDATE clientes SET email = ? WHERE cpf = ? ";
		
		try {
			
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ps.setString(1, "pedrao2@mail.com");
			ps.setString(2, "111");
			
			int retorno				= ps.executeUpdate();
			System.out.println(retorno);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// EXEMPLO DELETE
		
		sql = "DELETE FROM clientes WHERE cpf = ? ";
		
		try {
			
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ps.setString(1, "111");
			
			int retorno				= ps.executeUpdate();
			System.out.println(retorno);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		


	}

}
