package heranca;

import java.sql.*;

public class Pessoa {

	public String cpf, nome, email, sql;

	public int save() {
		Connection conn = Banco.conectar();
		System.out.println(conn);
		
		
		try {
			PreparedStatement ps 	= conn.prepareStatement(this.sql);
			ps.setString(1, null);
			ps.setString(2, "1");	
			ps.setString(3, this.cpf);
			ps.setString(4, this.nome);
			ps.setString(5, this.email);
			
			int retorno 			= ps.executeUpdate();
		
			return retorno;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		
	}
}
