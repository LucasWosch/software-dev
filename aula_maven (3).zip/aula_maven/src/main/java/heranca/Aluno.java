package heranca;

public class Aluno extends Pessoa{
	
	String matricula;
	
}
