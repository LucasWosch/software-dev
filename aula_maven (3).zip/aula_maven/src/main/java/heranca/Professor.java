package heranca;

public class Professor extends Pessoa{
	String matricula;
	
	String sql = "INSERT INTO professor VALUES(?,?,?,?,?)";
	
	@Override
	public int save() {
		return super.save();
	}
}
