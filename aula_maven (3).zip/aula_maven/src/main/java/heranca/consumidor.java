package heranca;

import java.util.Scanner;

public class consumidor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner teclado 	= new Scanner(System.in);
		String opcaoSubMenu = "";
		Aluno aluno;
		Professor professor;
		

		while(!opcaoSubMenu.equals(0)) 
		{

			System.out.println("=====================================================");
			System.out.println("1 - Aluno");
			System.out.println("2 - Professor");
			System.out.println("0 - Voltar");
			
			System.out.println("=====================================================");
			System.out.print("Digite a opção desejada: ");
			
			opcaoSubMenu 		= teclado.nextLine();
			
			if(opcaoSubMenu.equals("1")) {
				aluno		= new Aluno();
				System.out.print("Digite o Matricula do cliente: ");
				aluno.matricula = teclado.nextLine();
				System.out.print("Digite o CPF do cliente: ");
				aluno.cpf 		= teclado.nextLine();
				System.out.print("Digite o Nome do cliente: ");
				aluno.nome 		= teclado.nextLine();
				System.out.print("Digite o E-mail do cliente: ");
				aluno.email 	= teclado.nextLine();
				
				aluno.save();
				
			}
			else if(opcaoSubMenu.equals("2")) {
				professor			= new Professor();
				System.out.print("Digite o Matricula do cliente: ");
				professor.matricula = teclado.nextLine();
				System.out.print("Digite o CPF do cliente: ");
				professor.cpf 		= teclado.nextLine();
				System.out.print("Digite o Nome do cliente: ");
				professor.nome 		= teclado.nextLine();
				System.out.print("Digite o E-mail do cliente: ");
				professor.email 	= teclado.nextLine();
				
				professor.save();
				
			}
		}
	}

}
