package exercicio_lk;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Cliente {
	
	public String cpf, nome, email, telefone;

	public Cliente(String cpf, String nome, String email, String telefone){
		
		this.cpf 		= cpf;
		this.nome 		= nome;
		this.email		= email;
		this.telefone 	= telefone;
		
	}
	
	public Cliente() {
		
	}
	
	public boolean salvar() {
		


		String filePathString	= "C:\\Users\\Aluno\\Documents\\teste\\clientes.csv";
		String separador 		= ",";
		String linha			= "";
		File f 					= new File(filePathString);
		FileWriter arquivo;
		
		if(!(f.exists() && !f.isDirectory())) {
			linha 	   		   += "cpf,nome,email,telefone" + System.lineSeparator();
		}
		try {				
			arquivo 		 	= new FileWriter("C:\\Users\\Aluno\\Documents\\teste\\clientes.csv", true);
			linha 			   += this.cpf + separador + this.nome + separador + this.email + separador + this.telefone +  System.lineSeparator();
			arquivo.write(linha);
			arquivo.flush();
			arquivo.close();
		}
		 catch (IOException e) {
				return false;
		}
		
		return true;
	}
	
	
	public boolean find_one(String cpf) throws IOException {
		String separador 		= ",";
		String filePathString	= "C:\\Users\\Aluno\\Documents\\teste\\clientes.csv";
		String nomeFile			= "clientes.csv";
		
		try {
			FileReader  reader 	= new FileReader(filePathString);
			BufferedReader br 	= new BufferedReader(reader);
			String linha 		= br.readLine();
			linha 				= br.readLine();
			while(linha != null) {
				if(cpf.equals(linha.split(separador)[0])) {
					this.cpf		= linha.split(separador)[0];
					this.nome		= linha.split(separador)[1];
					this.email		= linha.split(separador)[2];
					this.telefone	= linha.split(separador)[3];
					return true;
				}
				linha = br.readLine();
			}
		}
		 catch (IOException e) {
	            throw new IOException("Erro ao ler o arquivo: " + nomeFile, e);
		 }
		return false;
	}
	
	public ArrayList<Cliente> find_all(){
        ArrayList<Cliente> allClientes 	= new ArrayList<Cliente>();
		String separador 				= ",";
		String filePathString			= "C:\\Users\\Aluno\\Documents\\teste\\clientes.csv";
		
		try {
			FileReader  reader 			= new FileReader(filePathString);
			BufferedReader br 			= new BufferedReader(reader);
			String linha 				= br.readLine();
			linha 						= br.readLine();
			while(linha != null) {
				allClientes.add(new Cliente(linha.split(separador)[0], linha.split(separador)[1], linha.split(separador)[2], linha.split(separador)[3]));
				linha 					= br.readLine();
			}
		}
		catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return allClientes;
	}
	
	
	
}
