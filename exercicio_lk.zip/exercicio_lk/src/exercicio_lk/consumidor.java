package exercicio_lk;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class consumidor {

	public static void main(String[] args) {

		String opcaoMenu 		= "";
		Scanner teclado 		= new Scanner(System.in);
		Cliente cliente;
		String cpf;
		
		System.out.println("=============================================================");
		System.out.println("                          BEM-VINDO                          ");
		System.out.println("=============================================================");
		
		while(!opcaoMenu.equals("5")) {
			System.out.println("=============================================================");
			System.out.println("1 - Salvar Cliente");
			System.out.println("2 - Busque uma conta");
			System.out.println("3 - Liste todas as contas");
			System.out.println("5 - Sair");
			System.out.println("-------------------------------------------------------------");
			System.out.print("Digite a opção desejada: ");
			
			opcaoMenu 			= teclado.nextLine();
			
			if (opcaoMenu.equals("1")) {
				
				cliente = new Cliente();
				System.out.println("=============================================================");
				System.out.print("Digite o CPF do cliente: ");
				cliente.cpf 			= teclado.nextLine();
				System.out.print("Digite o Nome do cliente: ");
				cliente.nome 			= teclado.nextLine();
				System.out.print("Digite o Email do cliente: ");
				cliente.email 			= teclado.nextLine();
				System.out.print("Digite o Telefone do cliente: ");
				cliente.telefone 		= teclado.nextLine();
				
				if(cliente.salvar()) {
					System.out.println("=============================================================");
					System.out.println("                        CLIENTE SALVO                        ");
					System.out.println("=============================================================");
					System.out.println("Pressione Enter para continuar...");
					opcaoMenu	= teclado.nextLine();
				}
				
			}
			
			if (opcaoMenu.equals("2")) {
				
				cliente = new Cliente();
				System.out.println("=============================================================");
				System.out.print("Digite o CPF do cliente: ");
				cpf 			= teclado.nextLine();
				try {
					if(cliente.find_one(cpf)) {
						System.out.println(cliente.cpf);
						System.out.println(cliente.nome);
						System.out.println(cliente.email);
						System.out.println(cliente.telefone);
					}
				} catch (IOException e) {
		            throw new IOException("Erro ao ler o arquivo", e);
					e.printStackTrace();
				}
				
			}
			
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
//		
//		ArrayList<Cliente> allClientes;
//		try {
//			allClientes = cliente.find_all();
//			if(allClientes.size() > 0) {
//				for(int countClientes = 0; countClientes < allClientes.size(); countClientes++) {	
//					System.out.println(countClientes + "----------------------------");
//					System.out.println(allClientes.get(countClientes).cpf);		
//					System.out.println(allClientes.get(countClientes).nome);		
//					System.out.println(allClientes.get(countClientes).email);		
//					System.out.println(allClientes.get(countClientes).telefone);
//				}
//			}
//		}
//		catch(Exception e) {
//		}
		
	}

}
