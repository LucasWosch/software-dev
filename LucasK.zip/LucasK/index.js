/* 
    Programa data hora em node
    Autor: Lucas K.
    Data: 03/04/2023
*/

const express   = require("express");
const app       = express();

app.get("/hora",(req,res) => {
    const now = new Date();
    
    const hour = ("0" + now.getHours()).slice(-2);
    const minute = ("0" + now.getMinutes()).slice(-2);
    const second = ("0" + now.getSeconds()).slice(-2);

    res.send(`${hour}:${minute}:${second}`);
});

app.get("/data",(req,res) => {
    const now = new Date();
    
    const year = now.getFullYear();
    const month = ("0" + (now.getMonth() + 1)).slice(-2);
    const day = ("0" + now.getDate()).slice(-2);

    res.send(`${day}/${month}/${year}`);
});

const PORT      = 3000;
app.listen(PORT,() => {
    console.log(`Rodando na porta ${PORT}`);
});