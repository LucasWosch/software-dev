package banco_de_dados;

import java.sql.*;

public class Banco {
	
	private String url 		= "jdbc:mysql://localhost:3306/javadatabase";
	private String user 	= "root";
	private String password	= "positivo";

	public Connection init() {	
		Connection conn		= null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn			= DriverManager.getConnection(url, user, password);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return conn;
	}
}
