import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Cliente {

	public String cpf, nome, email;
	public Conta_Corrente conta;
	
	public String gerar_json() {
		
		GsonBuilder builder = new GsonBuilder();
		builder.setPrettyPrinting();
		
		Gson gson	 		= builder.create();
		return gson.toJson(this);
	}
}
