package coisas_e_coisas;

public class Cliente {

	public String cpf, nome, email, telefone, endereco;
	public int tipo_user = 1;
	
	public Cliente(String cpf, String nome, String email, String telefone, String endereco) {
		this.cpf 		= cpf;
		this.nome 		= nome;
		this.email 		= email;
		this.telefone 	= telefone;
		this.endereco 	= endereco;
	}

}
