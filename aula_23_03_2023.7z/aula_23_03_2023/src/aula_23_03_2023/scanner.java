package aula_23_03_2023;

import java.util.Scanner;

public class scanner {

	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		String 	nome;
		
		System.out.println("nome: ");
		nome			= teclado.nextLine();
		
		System.out.println(nome);

	}

}
