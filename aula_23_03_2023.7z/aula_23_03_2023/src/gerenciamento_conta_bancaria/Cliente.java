package gerenciamento_conta_bancaria;

import java.util.ArrayList;
public class Cliente {

	String CPF, Nome, Email;
	ArrayList<Conta> conta = new ArrayList<Conta>();
	
	public ArrayList<String> ListarContas()
	{
		
	}

	
	
	
	
	
	
	
}
