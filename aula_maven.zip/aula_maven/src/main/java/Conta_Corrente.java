
public class Conta_Corrente {
	public String numero;
	public int tipo;
	public double saldo;
}
