package aula_maven_mapeamento;

import java.util.ArrayList;

public class Estante {

	public ArrayList<Prateleira> prateleiras = new ArrayList<Prateleira>();
}
