package aula_maven_mapeamento;

public class consumidor_estante {

	public static void main(String[] args) {
		
		Livro livro 			= new Livro();
		Prateleira prateleira 	= new Prateleira();
		Estante estante 		= new Estante();
		
		livro.titulo			= "Vidas Secas";
		livro.autor				= "Graciliano R,";
		livro.edicao 			= "2a. Edição";
		
		prateleira.livros.add(livro);
		
		livro 					= new Livro();
		
		livro.titulo			= "Capitães de Areia";
		livro.autor				= "Jorge A.";
		livro.edicao 			= "1a. Edição";
		
		prateleira.livros.add(livro);
		estante.prateleiras.add(prateleira);
		
		for(int countLivros = 0; countLivros < prateleira.livros.size(); countLivros++) {			
			System.out.println(prateleira.livros.get(countLivros).titulo);
		}
		
	}

}
