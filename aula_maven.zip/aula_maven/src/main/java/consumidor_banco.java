import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class consumidor_banco {

	public static void main(String[] args) {
		Cliente cliente 		= new Cliente();
		Conta_Corrente conta 	= new Conta_Corrente();
		Banco banco 			= new Banco();
		
		cliente.cpf 			= "888";
		cliente.nome 			= "Pedro de Lara";
		cliente.email 			= "plara@mail.com";
		
		System.out.println(cliente.gerar_json());

	}

}
