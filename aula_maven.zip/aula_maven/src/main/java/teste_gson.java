import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class teste_gson {

	public static void main(String[] args) {
//		GsonBuilder builder = new GsonBuilder();
//		builder.setPrettyPrinting();

		String jsonString = "{\"nome\":\"Mahesh\", \"idade\":21}"; 
	  
		GsonBuilder builder = new GsonBuilder(); 
		builder.setPrettyPrinting(); 
	  
		Gson gson = builder.create(); 
		Aluno student = gson.fromJson(jsonString, Aluno.class); 
		System.out.println(student);    
	  
		jsonString = gson.toJson(student); 
		System.out.println(jsonString);  

	}

}
