package coisas_e_coisas;

import java.sql.*;
import java.util.ArrayList;

public class Pessoa {
	
	public String cpf, nome, email, telefone, endereco, tipo_user;
	public int id;
	
	public Pessoa() {}
	
	private Pessoa(int id, String cpf, String nome, String email, String telefone, String endereco) {
		this.id 		= id;
		this.cpf	 	= cpf;
		this.nome 		= nome;
		this.email 		= email;
		this.telefone 	= telefone;
		this.endereco 	= endereco;
	} 
	
	public int save() {
		
		if(this.find_one(this.cpf) == 0){
			Connection conn = Banco.conectar();
			
			String sql;
			sql = "INSERT INTO usuarios VALUES(?,?,?,?,?,?,?,?)";
			
			try {
				PreparedStatement ps 	= conn.prepareStatement(sql);
				ps.setString(1, null);
				ps.setString(2, this.cpf);
				ps.setString(3, this.nome);
				ps.setString(4, this.email);	
				ps.setString(5, this.telefone);	
				ps.setString(6, this.endereco);	
				ps.setString(7, this.tipo_user);	
				ps.setString(8, "1");	
				
				int retorno 			= ps.executeUpdate();
				this.find_one(this.cpf);
				return 1;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			return 2;
		}
		return 0;
		
	}
	
	
	public int find_one(String cpf) {

		Connection conn = Banco.conectar();
		String sql;
		
		sql = "SELECT * FROM usuarios WHERE cpf = ? LIMIT 1";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, cpf);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	this.id 		= rs.getInt("id");
                this.cpf 		= rs.getString("cpf");
                this.nome 		= rs.getString("nome");
                this.email 		= rs.getString("email");
                this.telefone 	= rs.getString("telefone");
                this.endereco 	= rs.getString("endereco");
                this.tipo_user	= rs.getString("tipo_user");
                
                return 1;
            }
            return 0;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	

	public ArrayList<Pessoa> find_all(){
		
		Connection conn = Banco.conectar();
		String sql;
		ArrayList<Pessoa> allPessoas = new ArrayList<Pessoa>();
		
		sql = "SELECT * FROM usuarios WHERE tipo_user = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, this.tipo_user);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	
            	allPessoas.add(new Pessoa(rs.getInt("id"), rs.getString("cpf"),rs.getString("nome"),rs.getString("email"),rs.getString("telefone"),rs.getString("endereco")));
            }
            return allPessoas;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public int delete() {

		Connection conn = Banco.conectar();
		String sql;
		
		if(this.tipo_user.equals("2")) {

			sql = "DELETE FROM prestador_servico WHERE fk_prestador = ?";
			
			try {
				PreparedStatement ps = conn.prepareStatement(sql);
				ps.setInt(1, this.id);
				ps.executeUpdate();
	            return 1;
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
		sql = "DELETE FROM usuarios WHERE cpf = ? AND tipo_user = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, this.cpf);
			ps.setString(2, this.tipo_user);
			ps.executeUpdate();
            return 1;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	
}
