package coisas_e_coisas;


public class Menu {

	public void cabecalho () {
	
		System.out.println("=====================================================");
		System.out.println("                   COISAS E COISAS                   ");
		System.out.println("=====================================================");
	}
	
	public void menu_principal() {
		
		this.cabecalho();
		
		System.out.println("1 - Clientes");
		System.out.println("2 - Prestadores");
		System.out.println("3 - Tipos Serviços");
		System.out.println("4 - Serviços");
		System.out.println("5 - Sair");
		
		this.get_option();
		
	}
	
	public void get_option() {
		
		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");
	}
	
}
