package coisas_e_coisas;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Servico {

	public Cliente cliente;
	public Prestador prestador;
	public TipoServico tipoServico;
	public String dataServico;
	public double valorServico;
	
	public int save() {
		
		Connection conn = Banco.conectar();
		
		String sql;
		sql = "INSERT INTO servicos VALUES(?,?,?,?,?,?)";
		
		try {
			PreparedStatement ps 	= conn.prepareStatement(sql);
			ps.setString(1, null);
			ps.setInt(2, this.cliente.id);
			ps.setInt(3, this.prestador.id);
			ps.setInt(4, this.tipoServico.id);
			ps.setString(5, this.dataServico);
			ps.setDouble(6, this.valorServico);
			
			int retorno 			= ps.executeUpdate();
			return 1;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}
}
