package coisas_e_coisas;

import java.sql.*;
import java.util.ArrayList;

public class Prestador extends Pessoa{
	
	public ArrayList<TipoServico> tiposServico;
	
	public Prestador() {		
		this.tipo_user 		= "2";
		this.tiposServico 	= new ArrayList<TipoServico>();
	}
	

	public int save_servicos(){
		
		if(tiposServico != null && tiposServico.size() > 0) {
			
			Connection conn = Banco.conectar();
			String sql;
			
			for(int countServicos = 0; countServicos < tiposServico.size(); countServicos++) {	
				sql = "INSERT INTO prestador_servico VALUES(?,?,?)";
				
				try {
					PreparedStatement ps 	= conn.prepareStatement(sql);
					ps.setString(1, null);
					ps.setInt(2, this.id);
					ps.setInt(3, tiposServico.get(countServicos).id);
					
					int retorno 			= ps.executeUpdate();
				
					return retorno;
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return 1;
		
	}
	
	public ArrayList<TipoServico> find_services(){
		
		Connection conn = Banco.conectar();
		String sql;
		TipoServico tipoServico = new TipoServico();
		ArrayList<TipoServico> allTiposServicos 	= new ArrayList<TipoServico>();
		
		sql = "SELECT tipo_servicos.nome_servico FROM prestador_servico INNER JOIN tipo_servicos ON fk_servico = tipo_servicos.id WHERE fk_prestador = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, this.id);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	tipoServico.find_one(rs.getString("nome_servico"));
            	allTiposServicos.add(tipoServico);
            }
            return allTiposServicos;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
}
