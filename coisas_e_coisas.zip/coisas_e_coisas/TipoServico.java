package coisas_e_coisas;

import java.sql.*;
import java.util.ArrayList;

public class TipoServico {
	
	public String nome, desc;
	public int status = 1;
	public int id;

	public TipoServico() {}

	private TipoServico(int id, String nome, String desc){
		
		this.id		 	= id;
		this.nome 		= nome;
		this.desc 		= desc;
		
	}


	public ArrayList<Prestador> prestadores;
	
	public int save() {
		Connection conn = Banco.conectar();
		
		if(this.find_one(this.nome) == 0) {			
			String sql;
			sql = "INSERT INTO tipo_servicos VALUES(?,?,?,?)";
			
			try {
				PreparedStatement ps 	= conn.prepareStatement(sql);
				ps.setString(1, null);
				ps.setString(2, this.nome);
				ps.setString(3, this.desc);	
				ps.setInt(4, this.status);
				
				int retorno 			= ps.executeUpdate();
				
				this.find_one(this.nome);
				
				return 1;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			return 2;
		}
		return 0;
		
	}
	
	public int find_one(String nome) {

		Connection conn = Banco.conectar();
		String sql;
		
		sql = "SELECT * FROM tipo_servicos WHERE nome_servico = ? LIMIT 1";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, nome);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	this.id 		= rs.getInt("id");
                this.nome 		= rs.getString("nome_servico");
                this.desc 		= rs.getString("desc_servico");
                
                return 1;
            }
            
            return 0;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
		
	}
	

	public ArrayList<TipoServico> find_all(){
		
		Connection conn = Banco.conectar();
		String sql;
		ArrayList<TipoServico> allTiposServicos 	= new ArrayList<TipoServico>();
		
		sql = "SELECT * FROM tipo_servicos";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	
            	allTiposServicos.add(new TipoServico(rs.getInt("id"), rs.getString("nome_servico"),rs.getString("desc_servico")));
            }
            return allTiposServicos;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	
	public ArrayList<Prestador> find_prestadores(){
		
		Connection conn 						= Banco.conectar();
		String sql;
		Prestador prestador 					= new Prestador();
		ArrayList<Prestador> allPrestadores 	= new ArrayList<Prestador>();
		
		sql = "SELECT usuarios.cpf FROM prestador_servico INNER JOIN usuarios ON prestador_servico.fk_prestador = usuarios.id WHERE fk_servico = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, this.id);
			ResultSet rs = ps.executeQuery();

            while (rs.next()) {
            	prestador.find_one(rs.getString("cpf"));
            	allPrestadores.add(prestador);
            }
            return allPrestadores;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	public int delete() {

		Connection conn = Banco.conectar();
		String sql;
		

		sql = "DELETE FROM prestador_servico WHERE fk_servico = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, this.id);
			ps.executeUpdate();
            return 1;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		
		sql = "DELETE FROM tipo_servicos WHERE id = ?";
		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, this.id);
			ps.executeUpdate();
            return 1;
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	
}
