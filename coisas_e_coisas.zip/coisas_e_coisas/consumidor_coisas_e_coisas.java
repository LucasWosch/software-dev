package coisas_e_coisas;

import java.util.ArrayList;
import java.util.Scanner;

public class consumidor_coisas_e_coisas {

	public static void main(String[] args) {

		String opcaoMenu 			= "";
		String opcaoSubMenu			= "";
		String opcaoCliente			= "";
		String opcaoPrestador		= "";
		String servicoEscolhido 	= "";
		String clienteEscolhido		= "";
		String opcaoServico			= "";
		String dataServico			= "";
		String addOtherService 		= ""; 
		String addOtherPrestador 	= "";
		Scanner teclado 			= new Scanner(System.in);
		Cliente cliente;
		Prestador prestador;
		Servico servico;
		double valorServico			= 0;
		TipoServico tipoServico;
		Menu menu					= new Menu();
		
		
		do{
		
			menu.menu_principal();
			opcaoMenu 			= teclado.nextLine();
			
			if(opcaoMenu.equals("1")) {
				System.out.println("=====================================================");
				System.out.println("                   COISAS E COISAS                   ");
				System.out.println("=====================================================");
				
				System.out.println("1 - Cadastrar Cliente");
				System.out.println("2 - Visualizar Cliente");
				System.out.println("3 - Visualizar Clientes");
				System.out.println("4 - Deletar Cliente");
				System.out.println("0 - Voltar");
	
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR CLIENTE
				
				if(opcaoSubMenu.equals("1")) {
					
					cliente = new Cliente();
					
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("=====================================================");
					
					System.out.print("Digite o CPF do cliente: ");
					cliente.cpf 		= teclado.nextLine();
					System.out.print("Digite o Nome do cliente: ");
					cliente.nome 		= teclado.nextLine();
					System.out.print("Digite o E-mail do cliente: ");
					cliente.email 		= teclado.nextLine();
					System.out.print("Digite o Telefone do cliente: ");
					cliente.telefone	= teclado.nextLine();
					System.out.print("Digite o Endereço do cliente: ");
					cliente.endereco	= teclado.nextLine();
					
					if(cliente.save() > 0) {
						System.out.println("=====================================================");
						System.out.println("           CLIENTE CADASTRADO COM SUCESSO!           ");
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						
						opcaoMenu 		= teclado.nextLine();
					}
				}
				
	//			VISUALIZAR CLIENTE
				
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do cliente: ");
					
					cliente 			= new Cliente();					
					
					if(cliente.find_one(teclado.nextLine()) > 0) {
						System.out.println("=====================================================");
						System.out.println("                 CLIENTE ENCONTRADO!                 ");
						System.out.println("=====================================================");
						System.out.println("Informações de " + cliente.nome + ":");
						System.out.println("-----------------------------------------------------");
						System.out.println("CPF: " + cliente.cpf);
						System.out.println("Nome: " + cliente.nome);
						System.out.println("Email: " + cliente.email);
						System.out.println("Telefone: " + cliente.telefone);
						System.out.println("Endereço: " + cliente.endereco);
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
				
				else if(opcaoSubMenu.equals("3")) {
					System.out.println("=====================================================");

					cliente = new Cliente();
					
					ArrayList<Pessoa> allClientes;
					try {
						allClientes = cliente.find_all();							
						if(allClientes.size() > 0) {
							
							for(int countCliente = 0; countCliente < allClientes.size(); countCliente++) {	
								System.out.println("-----------------------------------------------------");
								System.out.println((countCliente + 1) + " - " + allClientes.get(countCliente).nome);		
							}
						}
					}
					catch(Exception e) {}
					System.out.println("=====================================================");
					System.out.println("Pressione Enter para continuar...");
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR CLIENTE
				
				else if(opcaoSubMenu.equals("4")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do cliente: ");
					
					cliente 			= new Cliente();					
					
					if(cliente.find_one(teclado.nextLine()) > 0) {
						if(cliente.delete() > 0) {							
							System.out.println("=====================================================");
							System.out.println("                  CLIENTE DELETADO!                  ");
							System.out.println("=====================================================");
							System.out.println("Pressione Enter para continuar...");
							opcaoMenu 		= teclado.nextLine();
						}
					}
					
				}
				
			}
			
			
			
			else if(opcaoMenu.equals("2")) {
				System.out.println("=====================================================");
				System.out.println("                   COISAS E COISAS                   ");
				System.out.println("=====================================================");
				
				System.out.println("1 - Cadastrar Prestador");
				System.out.println("2 - Visualizar Prestrador");
				System.out.println("3 - Visualizar Prestadores");
				System.out.println("4 - Deletar Prestador");
				System.out.println("0 - Voltar");
	
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR CLIENTE
				
				if(opcaoSubMenu.equals("1")) {
					
					prestador = new Prestador();
					
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("=====================================================");
					
					System.out.print("Digite o CPF do prestador: ");
					prestador.cpf 		= teclado.nextLine();
					System.out.print("Digite o Nome do prestador: ");
					prestador.nome 		= teclado.nextLine();
					System.out.print("Digite o E-mail do prestador: ");
					prestador.email 	= teclado.nextLine();
					System.out.print("Digite o Telefone do prestador: ");
					prestador.telefone	= teclado.nextLine();
					System.out.print("Digite o Endereço do prestador: ");
					prestador.endereco	= teclado.nextLine();
					
					if(prestador.save() > 0) {
						System.out.println("=====================================================");
						System.out.println("          PRESTADOR CADASTRADO COM SUCESSO!          ");
						System.out.println("=====================================================");
						System.out.println("1 - Vincula-lo em um tipo de serviço");
						System.out.println("0 - Voltar");
						System.out.println("-----------------------------------------------------");
						System.out.print("Digite a opção desejada: ");
						
						opcaoPrestador 	= teclado.nextLine();
						
						if(opcaoPrestador.equals("1")) {
							System.out.println("=====================================================");

							tipoServico = new TipoServico();
							
							ArrayList<TipoServico> allTiposServicos;
							try {
								allTiposServicos = tipoServico.find_all();
								while(!addOtherService.equals("N")) {									
									if(allTiposServicos.size() > 0) {
										
										for(int countServico = 0; countServico < allTiposServicos.size(); countServico++) {	
											System.out.println("-----------------------------------------------------");
											System.out.println((countServico + 1) + " - " + allTiposServicos.get(countServico).nome);		
										}
										
										System.out.println("=====================================================");
										System.out.print("Digite o serviço desejado: ");
										servicoEscolhido	= teclado.nextLine();
										tipoServico.find_one(allTiposServicos.get(Integer.parseInt(servicoEscolhido) - 1).nome);
										prestador.tiposServico.add(tipoServico);
										
										System.out.println("=====================================================");
										System.out.print("Deseja adicionar um novo serviço (S/N): ");
										addOtherService		= teclado.nextLine();
										
									}
									
									prestador.save_servicos();
								}
							}
							catch(Exception e) {
								System.out.println(e);
							}
						}
					}
				}
				
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do prestador: ");
					
					prestador 		= new Prestador();					
					
					if(prestador.find_one(teclado.nextLine()) > 0) {
						System.out.println("=====================================================");
						System.out.println("                PRESTADOR ENCONTRADO!                ");
						System.out.println("=====================================================");
						System.out.println("Informações de " + prestador.nome + ":");
						System.out.println("-----------------------------------------------------");
						System.out.println("CPF: " + prestador.cpf);
						System.out.println("Nome: " + prestador.nome);
						System.out.println("Email: " + prestador.email);
						System.out.println("Telefone: " + prestador.telefone);
						System.out.println("Endereço: " + prestador.endereco);
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
				
				else if(opcaoSubMenu.equals("3")) {
					System.out.println("=====================================================");

					prestador = new Prestador();
					
					ArrayList<Pessoa> allPrestadores;
					try {
						allPrestadores = prestador.find_all();							
						if(allPrestadores.size() > 0) {
							
							for(int countPrestador = 0; countPrestador < allPrestadores.size(); countPrestador++) {	
								System.out.println("-----------------------------------------------------");
								System.out.println((countPrestador + 1) + " - " + allPrestadores.get(countPrestador).nome);		
							}
						}
					}
					catch(Exception e) {}
					System.out.println("=====================================================");
					System.out.println("Pressione Enter para continuar...");
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR PRESTADOR
				
				else if(opcaoSubMenu.equals("4")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do prestador: ");
					
					prestador 			= new Prestador();					
					
					if(prestador.find_one(teclado.nextLine()) > 0) {
						if(prestador.delete() > 0) {							
							System.out.println("=====================================================");
							System.out.println("                 PRESTADOR DELETADO!                 ");
							System.out.println("=====================================================");
							System.out.println("Pressione Enter para continuar...");
							opcaoMenu 		= teclado.nextLine();
						}
					}
					
				}
				
			}
			
			
			
			
			else if(opcaoMenu.equals("3")) {
				menu.cabecalho();
				
				System.out.println("1 - Cadastrar Tipo de Serviço");
				System.out.println("2 - Visualizar Tipo de Serviço");
				System.out.println("3 - Visualizar Tipos de Serviço");
				System.out.println("4 - Deletar Tipo de Serviço");
				System.out.println("0 - Voltar");
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR TIPO DE SERVIÇO
				
				if(opcaoSubMenu.equals("1")) {
					
					tipoServico = new TipoServico();
					
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("=====================================================");
					
					System.out.print("Digite o Nome do tipo do serviço: ");
					tipoServico.nome 		= teclado.nextLine();
					System.out.print("Digite a Descrição do tipo do serviço: ");
					tipoServico.desc 		= teclado.nextLine();
					
					if(tipoServico.save() > 0) {
						System.out.println("=====================================================");
						System.out.println("           SERVIÇO CADASTRADO COM SUCESSO!           ");
						System.out.println("=====================================================");
						System.out.println("1 - Vincula-lo em um tipo de serviço");
						System.out.println("0 - Voltar");
						System.out.println("-----------------------------------------------------");
						System.out.print("Digite a opção desejada: ");
						
						opcaoServico = teclado.nextLine();
						
						if(opcaoServico.equals("1")) {
							System.out.println("=====================================================");

							prestador = new Prestador();
							
							ArrayList<Pessoa> allPrestadores;
							try {
								allPrestadores = prestador.find_all();
								while(!addOtherPrestador.equals("N")) {									
									if(allPrestadores.size() > 0) {
										
										for(int countPrestador = 0; countPrestador < allPrestadores.size(); countPrestador++) {	
											System.out.println("-----------------------------------------------------");
											System.out.println(allPrestadores.get(countPrestador).id + " - " + allPrestadores.get(countPrestador).nome);		
										}
										
										System.out.println("=====================================================");
										System.out.print("Digite o serviço desejado: ");
										servicoEscolhido	= teclado.nextLine();
										
										System.out.println("=====================================================");
										System.out.print("Deseja adicionar um novo serviço (S/N): ");
										addOtherService		= teclado.nextLine();
										
									}
								}
							}
							catch(Exception e) {
							}
						}
						
						
					}
				}
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o Nome do Serviço: ");
					
					tipoServico 		= new TipoServico();					
					
					if(tipoServico.find_one(teclado.nextLine()) > 0) {
						System.out.println("=====================================================");
						System.out.println("             TIPO DE SERVIÇO ENCONTRADO!             ");
						System.out.println("=====================================================");
						System.out.println("Nome:" + tipoServico.nome);
						System.out.println("Descrição: " + tipoServico.desc);

						ArrayList<Prestador> allPrestadoresServico = tipoServico.find_prestadores();
						
						if(allPrestadoresServico.size() > 0) {

							System.out.println("Prestadores: ");
							for(int countPrestador = 0; countPrestador < allPrestadoresServico.size(); countPrestador++) {	
								System.out.println("-----------------------------------------------------");
								System.out.println((countPrestador + 1) + " - " + allPrestadoresServico.get(countPrestador).nome);		
							}
						}
						
						
						
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
				
				else if(opcaoSubMenu.equals("3")) {
					System.out.println("=====================================================");

					tipoServico = new TipoServico();
					
					ArrayList<TipoServico> allTiposServicos;
					try {
						allTiposServicos = tipoServico.find_all();							
						if(allTiposServicos.size() > 0) {
							
							for(int countTipoServico = 0; countTipoServico < allTiposServicos.size(); countTipoServico++) {	
								System.out.println("-----------------------------------------------------");
								System.out.println((countTipoServico + 1) + " - " + allTiposServicos.get(countTipoServico).nome);		
							}
						}
					}
					catch(Exception e) {}
					System.out.println("=====================================================");
					System.out.println("Pressione Enter para continuar...");
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR PRESTADOR
				
				else if(opcaoSubMenu.equals("4")) {
					
					menu.cabecalho();
					System.out.print("Digite o Nome do Serviço: ");
					
					tipoServico		= new TipoServico();					
					
					if(tipoServico.find_one(teclado.nextLine()) > 0) {
						if(tipoServico.delete() > 0) {							
							System.out.println("=====================================================");
							System.out.println("              TIPO DE SERVIÇO DELETADO!              ");
							System.out.println("=====================================================");
							System.out.println("Pressione Enter para continuar...");
							opcaoMenu 		= teclado.nextLine();
						}
					}
					
				}
			}
			
			
			else if(opcaoMenu.equals("4")) {
				menu.cabecalho();
				
				System.out.println("1 - Cadastrar Serviço");
				System.out.println("2 - Visualizar Serviço");
				System.out.println("3 - Visualizar Serviços");
				System.out.println("4 - Deletar Serviço");
				System.out.println("0 - Voltar");
				System.out.println("=====================================================");
				System.out.print("Digite a opção desejada: ");
	
				opcaoSubMenu 		= teclado.nextLine();
				
				if(opcaoSubMenu.equals("1")) {
					
					servico = new Servico();
						
					System.out.println("=====================================================");
					System.out.println("                   COISAS E COISAS                   ");
					System.out.println("=====================================================");

					System.out.println("Selecione o Cliente do Serviço:");
					System.out.println("=====================================================");

					cliente = new Cliente();
					
					ArrayList<Pessoa> allClientes;
					try {
						allClientes = cliente.find_all();									
						if(allClientes.size() > 0) {
							
							for(int countCliente = 0; countCliente < allClientes.size(); countCliente++) {	
								System.out.println("-----------------------------------------------------");
								System.out.println((countCliente + 1) + " - " + allClientes.get(countCliente).nome);		
							}
							
							System.out.println("=====================================================");
							System.out.print("Digite o cliente desejado: ");
							clienteEscolhido	= teclado.nextLine();
							cliente.find_one(allClientes.get(Integer.parseInt(clienteEscolhido) - 1).cpf);
							servico.cliente = cliente;
							System.out.println("=====================================================");
							
						}
					}
					catch(Exception e) {
						System.out.println(e);
					}

					System.out.println("Selecione o Prestador do Serviço:");
					System.out.println("=====================================================");
	
					prestador = new Prestador();
					
					ArrayList<Pessoa> allPrestadores;
					try {
						allPrestadores = prestador.find_all();								
							if(allPrestadores.size() > 0) {
								
								for(int countCliente = 0; countCliente < allPrestadores.size(); countCliente++) {	
									System.out.println("-----------------------------------------------------");
									System.out.println((countCliente + 1) + " - " + allPrestadores.get(countCliente).nome);		
								}
								
								System.out.println("=====================================================");
								System.out.print("Digite o prestador desejado: ");
								clienteEscolhido	= teclado.nextLine();
								prestador.find_one(allPrestadores.get(Integer.parseInt(clienteEscolhido) - 1).cpf);
								servico.prestador  	= prestador;
								System.out.println("=====================================================");
								
							}
					}
					catch(Exception e) {
						System.out.println(e);
					}

					System.out.println("Selecione o Serviço Prestado:");
					System.out.println("=====================================================");
	
					tipoServico = new TipoServico();
					
					ArrayList<TipoServico> allServicos;
					try {
						allServicos = prestador.find_services();								
							if(allServicos.size() > 0) {
								
								for(int countServico = 0; countServico < allServicos.size(); countServico++) {	
									System.out.println("-----------------------------------------------------");
									System.out.println((countServico + 1) + " - " + allServicos.get(countServico).nome);		
								}
								
								System.out.println("=====================================================");
								System.out.print("Digite o serviço desejado: ");
								servicoEscolhido	= teclado.nextLine();
								tipoServico.find_one(allServicos.get(Integer.parseInt(servicoEscolhido) - 1).nome);
								servico.tipoServico = tipoServico;
								System.out.println("=====================================================");
								
							}
					}
					catch(Exception e) {
						System.out.println(e);
					}

					System.out.print("Digite a data do serviço(dd/mm/YYYY): ");
					dataServico				= teclado.nextLine();
					servico.dataServico 	= dataServico;
					
					System.out.print("Digite o valor do serviço: ");
					valorServico 			= Double.parseDouble(teclado.nextLine());
					servico.valorServico 	= valorServico;					
					
					if(servico.save() == 1) {
						System.out.println("=====================================================");
						System.out.println("           SERVIÇO CADASTRADO COM SUCESSO!           ");
						System.out.println("=====================================================");
						System.out.println("Pressione Enter para continuar...");
						opcaoMenu 		= teclado.nextLine();
						
					}

				}
			}
		
		}while(!opcaoMenu.equals("5"));
		
		
		
	

	}

}
