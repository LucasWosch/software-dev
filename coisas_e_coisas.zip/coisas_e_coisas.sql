-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 25/05/2023 às 23:03
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `coisas_e_coisas`
--
CREATE DATABASE IF NOT EXISTS `coisas_e_coisas` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `coisas_e_coisas`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `prestador_servico`
--

CREATE TABLE `prestador_servico` (
  `id` int(11) NOT NULL,
  `fk_prestador` int(11) NOT NULL,
  `fk_servico` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `prestador_servico`
--

INSERT INTO `prestador_servico` (`id`, `fk_prestador`, `fk_servico`) VALUES
(3, 11, 2);

-- --------------------------------------------------------

--
-- Estrutura para tabela `servicos`
--

CREATE TABLE `servicos` (
  `id` int(11) NOT NULL,
  `fk_cliente` int(11) NOT NULL,
  `fk_prestador` int(11) NOT NULL,
  `fk_servico` int(11) NOT NULL,
  `data` varchar(255) NOT NULL,
  `valor` double(11,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `servicos`
--

INSERT INTO `servicos` (`id`, `fk_cliente`, `fk_prestador`, `fk_servico`, `data`, `valor`) VALUES
(1, 2, 12, 3, '26/05/2023', 10.50),
(2, 2, 12, 3, '10/05/2023', 100.50);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tipo_servicos`
--

CREATE TABLE `tipo_servicos` (
  `id` int(11) NOT NULL,
  `nome_servico` varchar(255) NOT NULL,
  `desc_servico` varchar(255) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `tipo_servicos`
--

INSERT INTO `tipo_servicos` (`id`, `nome_servico`, `desc_servico`, `status`) VALUES
(2, 'Trocar lampada', 'trocar lampada', 1),
(3, 'Trocar torneira', 'Troca de torneira', 1),
(4, 'Cortar grama', 'Cortar a grama', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `cpf` varchar(255) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telefone` varchar(255) NOT NULL,
  `endereco` varchar(255) NOT NULL,
  `tipo_user` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `cpf`, `nome`, `email`, `telefone`, `endereco`, `tipo_user`, `status`) VALUES
(2, '123', 'Lucas', 'lucas@mail.com', '(41)12345-1234', 'Rua Teste 1', '1', '1'),
(3, '234', 'João', 'joão@mail.com', '(41)23456-1234', 'Rua Teste 2', '2', '1'),
(4, '345', 'Pedro', 'pedro@mail.com', '(41)34567-1234', 'Rua Teste 3', '2', '1'),
(5, '456', 'Carlos', 'carlos@email.com', '(41)45678-1234', 'Rua Teste 4', '2', '1'),
(7, '678', 'Leonardo', 'leo@mail.com', '(41)67890-1234', 'Rua Teste 6', '2', '1'),
(8, '789', 'Eduardo', 'edu@mail.com', '(41)78901-1234', 'Rua Teste 7', '2', '1'),
(9, '890', 'Luiz', 'luiz@mail.com', '(41)89012-1234', 'Rua Teste 8', '2', '1'),
(10, '901', 'José', 'jose@mail.com', '(41)90123-1234', 'Rua Teste 9', '2', '1'),
(11, '101', 'Guilherme', 'gui@mail.com', '(41)10121-1234', 'Rua Teste 10', '2', '1'),
(12, '111', 'Felipe', 'felipe@mail.com', '(41)11121-1234', 'Rua Teste 11', '2', '1');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `prestador_servico`
--
ALTER TABLE `prestador_servico`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_prestador` (`fk_prestador`),
  ADD KEY `fk_servico` (`fk_servico`);

--
-- Índices de tabela `servicos`
--
ALTER TABLE `servicos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_cliente` (`fk_cliente`),
  ADD KEY `fk_servico` (`fk_servico`);

--
-- Índices de tabela `tipo_servicos`
--
ALTER TABLE `tipo_servicos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `prestador_servico`
--
ALTER TABLE `prestador_servico`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `servicos`
--
ALTER TABLE `servicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tipo_servicos`
--
ALTER TABLE `tipo_servicos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `prestador_servico`
--
ALTER TABLE `prestador_servico`
  ADD CONSTRAINT `prestador_servico_ibfk_1` FOREIGN KEY (`fk_prestador`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `prestador_servico_ibfk_2` FOREIGN KEY (`fk_servico`) REFERENCES `tipo_servicos` (`id`);

--
-- Restrições para tabelas `servicos`
--
ALTER TABLE `servicos`
  ADD CONSTRAINT `servicos_ibfk_1` FOREIGN KEY (`fk_cliente`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `servicos_ibfk_2` FOREIGN KEY (`fk_cliente`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `servicos_ibfk_3` FOREIGN KEY (`fk_servico`) REFERENCES `tipo_servicos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
