package polimorfismo_2;

import java.util.ArrayList;

public class Estudante {

	public String matricula;
	public String cpf;
	public String nome;
	public String email;
	public ArrayList<InterCurso> cursos;
	
	public double getValorTotal() {
		double valorTotal = 0;
		for(int countCurso = 0; countCurso < cursos.size(); countCurso++) 
		{
			valorTotal += cursos.get(countCurso).custoCurso();
		}
		return valorTotal;
	}
	
	
}
