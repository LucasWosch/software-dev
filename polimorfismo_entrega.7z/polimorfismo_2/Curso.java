package polimorfismo_2;

public abstract class Curso implements InterCurso{

	public String nome;
	public double carga_horaria;
	public double parcela;
	public int tipo_curso;
	
	public String getName() {
		return this.nome;
	}

	public double custoCurso() {
	 return this.parcela;
	}
	
	
}
