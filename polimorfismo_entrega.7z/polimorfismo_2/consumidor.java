package polimorfismo_2;

import java.util.ArrayList;

public class consumidor {

	public static void main(String[] args) {
		
		Bacharelado bacharelado 				= new Bacharelado();
		BachareladoLaboratorio bacharelado_lab 	= new BachareladoLaboratorio();
		Estudante estudante						= new Estudante();
		
		bacharelado.nome 				= "BSI";
		bacharelado.carga_horaria 		= 20.5;
		bacharelado.parcela 			= 500.50;
		bacharelado.tipo_curso			= 1;
		
		bacharelado_lab.nome			= "ENG";
		bacharelado_lab.carga_horaria 	= 50.5;
		bacharelado_lab.parcela 		= 1500.50;
		bacharelado_lab.tipo_curso		= 2;
		bacharelado_lab.custolab		= 150.50;

		
		estudante.nome 					= "Pedro";
		estudante.email					= "pedro@teste.com";
		estudante.cpf					= "123456789-12";
		estudante.matricula				= "123";
		
		estudante.cursos 				= new ArrayList<InterCurso>();
		
		estudante.cursos.add(bacharelado);
		estudante.cursos.add(bacharelado_lab);		

		for(int countCurso = 0; countCurso < estudante.cursos.size(); countCurso++) {
			
			System.out.println((countCurso + 1) + " - " + estudante.cursos.get(countCurso).getName() + " - " + estudante.cursos.get(countCurso).custoCurso());		
		}
		System.out.println("Valor Total: "+ estudante.getValorTotal());
	}

}
