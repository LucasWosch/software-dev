package coisas_e_coisas;


public class Menu {

	public void cabecalho () {
	
		System.out.println("=====================================================");
		System.out.println("                   COISAS E COISAS                   ");
		System.out.println("=====================================================");
	}
	
	public void menu_principal() {
		
		this.cabecalho();
		
		System.out.println("1 - Clientes");
		System.out.println("2 - Prestadores");
		System.out.println("3 - Tipos Serviços");
		System.out.println("4 - Serviços");
		System.out.println("5 - Sair");
		
		this.get_option();
		
	}
	
	public void get_option() {
		
		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void menu_cliente() {
		System.out.println("=====================================================");
		System.out.println("                   COISAS E COISAS                   ");
		System.out.println("=====================================================");
		
		System.out.println("1 - Cadastrar Cliente");
		System.out.println("2 - Visualizar Cliente");
		System.out.println("3 - Visualizar Clientes");
		System.out.println("4 - Deletar Cliente");
		System.out.println("0 - Voltar");

		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void register_cliente_success(){

		System.out.println("=====================================================");
		System.out.println("           CLIENTE CADASTRADO COM SUCESSO!           ");
		System.out.println("=====================================================");
		System.out.println("Pressione Enter para continuar...");
	}
	
	public void deleted_cliente_success() {
		System.out.println("=====================================================");
		System.out.println("                  CLIENTE DELETADO!                  ");
		System.out.println("=====================================================");
		System.out.println("Pressione Enter para continuar...");
	}
	
	public void finded_cliente() {
		System.out.println("=====================================================");
		System.out.println("                 CLIENTE ENCONTRADO!                 ");
		System.out.println("=====================================================");
	}
	
	public void menu_prestador() {

		System.out.println("=====================================================");
		System.out.println("                   COISAS E COISAS                   ");
		System.out.println("=====================================================");
		
		System.out.println("1 - Cadastrar Prestador");
		System.out.println("2 - Visualizar Prestrador");
		System.out.println("3 - Visualizar Prestadores");
		System.out.println("4 - Deletar Prestador");
		System.out.println("0 - Voltar");

		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void register_prestador_success() {

		System.out.println("=====================================================");
		System.out.println("          PRESTADOR CADASTRADO COM SUCESSO!          ");
		System.out.println("=====================================================");
		System.out.println("1 - Vincula-lo em um tipo de serviço");
		System.out.println("0 - Voltar");
		System.out.println("-----------------------------------------------------");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void finded_prestador() {
		System.out.println("=====================================================");
		System.out.println("                PRESTADOR ENCONTRADO!                ");
		System.out.println("=====================================================");
	}
	
	public void deleted_prestador_success() {

		System.out.println("=====================================================");
		System.out.println("                 PRESTADOR DELETADO!                 ");
		System.out.println("=====================================================");
		System.out.println("Pressione Enter para continuar...");
	}
	
	public void menu_tipo_servico() {

		this.cabecalho();
		
		System.out.println("1 - Cadastrar Tipo de Serviço");
		System.out.println("2 - Visualizar Tipo de Serviço");
		System.out.println("3 - Visualizar Tipos de Serviço");
		System.out.println("4 - Deletar Tipo de Serviço");
		System.out.println("0 - Voltar");
		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void register_tipo_servico() {

		System.out.println("=====================================================");
		System.out.println("           SERVIÇO CADASTRADO COM SUCESSO!           ");
		System.out.println("=====================================================");
		System.out.println("1 - Vincula-lo a um prestador");
		System.out.println("0 - Voltar");
		System.out.println("-----------------------------------------------------");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void finded_tipo_servico_success() {
		System.out.println("=====================================================");
		System.out.println("             TIPO DE SERVIÇO ENCONTRADO!             ");
		System.out.println("=====================================================");
	}
	
	public void deleted_tipo_servico_success() {
		System.out.println("=====================================================");
		System.out.println("              TIPO DE SERVIÇO DELETADO!              ");
		System.out.println("=====================================================");
		System.out.println("Pressione Enter para continuar...");
	}
	
	public void menu_servico() {
		this.cabecalho();
		
		System.out.println("1 - Cadastrar Serviço");
		System.out.println("2 - Visualizar Serviços");
		System.out.println("3 - Deletar Serviço");
		System.out.println("0 - Voltar");
		System.out.println("=====================================================");
		System.out.print("Digite a opção desejada: ");
	}
	
	public void register_servico_success() {
		System.out.println("=====================================================");
		System.out.println("           SERVIÇO CADASTRADO COM SUCESSO!           ");
		System.out.println("=====================================================");
		System.out.println("Pressione Enter para continuar...");
	}
	
	public void deleted_servico_success() {
		System.out.println("=====================================================");
		System.out.println("                  SERVIÇO DELETADO!                  ");
		System.out.println("=====================================================");
		System.out.println("Pressione Enter para continuar...");
	}
	
	public void linha() {
		System.out.println("-----------------------------------------------------");
	}
	
	public void linha_dupla() {
		System.out.println("=====================================================");
	}
	
	public void wait_enter() {
		this.linha_dupla();
		System.out.println("Pressione Enter para continuar...");
	}
	
}
