package coisas_e_coisas;

import java.util.ArrayList;
import java.util.Scanner;

public class consumidor_coisas_e_coisas {

	public static void main(String[] args) {

		String opcaoMenu 			= "";
		String opcaoSubMenu			= "";
		String opcaoCliente			= "";
		String opcaoPrestador		= "";
		String servicoEscolhido 	= "";
		String clienteEscolhido		= "";
		String opcaoServico			= "";
		String dataServico			= "";
		String addOtherService 		= ""; 
		String addOtherPrestador 	= "";
		Scanner teclado 			= new Scanner(System.in);
		Cliente cliente;
		Prestador prestador;
		Servico servico;
		double valorServico			= 0;
		TipoServico tipoServico;
		Menu menu					= new Menu();
		
		
		do{
		
			menu.menu_principal();
			opcaoMenu 			= teclado.nextLine();
			
			if(opcaoMenu.equals("1")) {
				
				menu.menu_cliente();
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR CLIENTE
				
				if(opcaoSubMenu.equals("1")) {
					
					cliente = new Cliente();
					menu.cabecalho();
					
					System.out.print("Digite o CPF do cliente: ");
					cliente.cpf 		= teclado.nextLine();
					System.out.print("Digite o Nome do cliente: ");
					cliente.nome 		= teclado.nextLine();
					System.out.print("Digite o E-mail do cliente: ");
					cliente.email 		= teclado.nextLine();
					System.out.print("Digite o Telefone do cliente: ");
					cliente.telefone	= teclado.nextLine();
					System.out.print("Digite o Endereço do cliente: ");
					cliente.endereco	= teclado.nextLine();
					
					if(cliente.save() > 0) {
						
						menu.register_cliente_success();
						opcaoMenu 		= teclado.nextLine();
					}
				}
				
	//			VISUALIZAR CLIENTE
				
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do cliente: ");
					cliente 			= new Cliente();					
					
					if(cliente.find_one(teclado.nextLine()) > 0) {
						menu.finded_cliente();
						System.out.println("Informações de " + cliente.nome + ":");
						menu.linha();
						System.out.println("CPF: " + cliente.cpf);
						System.out.println("Nome: " + cliente.nome);
						System.out.println("Email: " + cliente.email);
						System.out.println("Telefone: " + cliente.telefone);
						System.out.println("Endereço: " + cliente.endereco);
						menu.wait_enter();
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
				
				else if(opcaoSubMenu.equals("3")) {
					
					menu.linha_dupla();
					cliente = new Cliente();
					ArrayList<Pessoa> allClientes;
					
					try {
						allClientes = cliente.find_all();							
						if(allClientes.size() > 0) {
							
							for(int countCliente = 0; countCliente < allClientes.size(); countCliente++) {	
								menu.linha();
								System.out.println((countCliente + 1) + " - " + allClientes.get(countCliente).nome);		
							}
						}
					}
					catch(Exception e) {}
					menu.wait_enter();
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR CLIENTE
				
				else if(opcaoSubMenu.equals("4")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do cliente: ");
					
					cliente 			= new Cliente();					
					
					if(cliente.find_one(teclado.nextLine()) > 0) {
						if(cliente.delete() > 0) {							
							menu.deleted_cliente_success();
							opcaoMenu 		= teclado.nextLine();
						}
					}
					
				}
				
			}
			
			
			
			else if(opcaoMenu.equals("2")) {
	
				menu.menu_prestador();
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR CLIENTE
				
				if(opcaoSubMenu.equals("1")) {
					
					prestador = new Prestador();
					
					menu.cabecalho();
					
					System.out.print("Digite o CPF do prestador: ");
					prestador.cpf 		= teclado.nextLine();
					System.out.print("Digite o Nome do prestador: ");
					prestador.nome 		= teclado.nextLine();
					System.out.print("Digite o E-mail do prestador: ");
					prestador.email 	= teclado.nextLine();
					System.out.print("Digite o Telefone do prestador: ");
					prestador.telefone	= teclado.nextLine();
					System.out.print("Digite o Endereço do prestador: ");
					prestador.endereco	= teclado.nextLine();
					
					if(prestador.save() > 0) {
						menu.register_prestador_success();
						opcaoPrestador 	= teclado.nextLine();
						
						if(opcaoPrestador.equals("1")) {
							menu.linha_dupla();

							tipoServico = new TipoServico();
							
							ArrayList<TipoServico> allTiposServicos;
							try {
								allTiposServicos = tipoServico.find_all();
								while(!addOtherService.equals("N")) {									
									if(allTiposServicos.size() > 0) {
										
										for(int countServico = 0; countServico < allTiposServicos.size(); countServico++) {	
											menu.linha();
											System.out.println((countServico + 1) + " - " + allTiposServicos.get(countServico).nome);		
										}

										menu.linha_dupla();
										System.out.print("Digite o serviço desejado: ");
										servicoEscolhido	= teclado.nextLine();
										tipoServico.find_one(allTiposServicos.get(Integer.parseInt(servicoEscolhido) - 1).nome);
										prestador.tiposServico.add(tipoServico);
										

										menu.linha_dupla();
										System.out.print("Deseja adicionar um novo serviço (S/N): ");
										addOtherService		= teclado.nextLine();
										
									}
									
									prestador.save_servicos();
								}
							}
							catch(Exception e) {
								System.out.println(e);
							}
						}
					}
				}
				
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do prestador: ");
					
					prestador 		= new Prestador();					
					
					if(prestador.find_one(teclado.nextLine()) > 0) {
						menu.finded_prestador();
						System.out.println("Informações de " + prestador.nome + ":");
						menu.linha();
						System.out.println("CPF: " + prestador.cpf);
						System.out.println("Nome: " + prestador.nome);
						System.out.println("Email: " + prestador.email);
						System.out.println("Telefone: " + prestador.telefone);
						System.out.println("Endereço: " + prestador.endereco);
						menu.wait_enter();
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
				
				else if(opcaoSubMenu.equals("3")) {
					menu.linha_dupla();

					prestador = new Prestador();
					
					ArrayList<Pessoa> allPrestadores;
					try {
						allPrestadores = prestador.find_all();							
						if(allPrestadores.size() > 0) {
							
							for(int countPrestador = 0; countPrestador < allPrestadores.size(); countPrestador++) {	
								menu.linha();
								System.out.println((countPrestador + 1) + " - " + allPrestadores.get(countPrestador).nome);		
							}
						}
					}
					catch(Exception e) {}
					menu.wait_enter();
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR PRESTADOR
				
				else if(opcaoSubMenu.equals("4")) {
					
					menu.cabecalho();
					System.out.print("Digite o CPF do prestador: ");
					
					prestador 			= new Prestador();					
					
					if(prestador.find_one(teclado.nextLine()) > 0) {
						if(prestador.delete() > 0) {			
							menu.deleted_prestador_success();
							opcaoMenu 		= teclado.nextLine();
						}
					}
					
				}
				
			}
			
			
			
			
			else if(opcaoMenu.equals("3")) {
				menu.menu_tipo_servico();
				opcaoSubMenu 		= teclado.nextLine();
				
	//			CADASTRAR TIPO DE SERVIÇO
				
				if(opcaoSubMenu.equals("1")) {
					
					tipoServico = new TipoServico();
					menu.cabecalho();
					
					System.out.print("Digite o Nome do tipo do serviço: ");
					tipoServico.nome 		= teclado.nextLine();
					System.out.print("Digite a Descrição do tipo do serviço: ");
					tipoServico.desc 		= teclado.nextLine();
					
					if(tipoServico.save() > 0) {
						menu.register_tipo_servico();
						opcaoServico = teclado.nextLine();
						
						if(opcaoServico.equals("1")) {
							menu.linha_dupla();

							prestador = new Prestador();
							
							ArrayList<Pessoa> allPrestadores;
							try {
								allPrestadores = prestador.find_all();
								while(!addOtherPrestador.equals("N")) {									
									if(allPrestadores.size() > 0) {
										
										for(int countPrestador = 0; countPrestador < allPrestadores.size(); countPrestador++) {	
											menu.linha();
											System.out.println(allPrestadores.get(countPrestador).id + " - " + allPrestadores.get(countPrestador).nome);		
										}
										
										menu.linha_dupla();
										System.out.print("Digite o prestador desejado: ");
										servicoEscolhido	= teclado.nextLine();

										menu.linha_dupla();
										System.out.print("Deseja adicionar um novo prestador (S/N): ");
										addOtherPrestador		= teclado.nextLine();
										
									}
								}
							}
							catch(Exception e) {
							}
						}
						
						
					}
				}
				else if(opcaoSubMenu.equals("2")) {
					
					menu.cabecalho();
					System.out.print("Digite o Nome do Serviço: ");
					
					tipoServico 		= new TipoServico();					
					
					if(tipoServico.find_one(teclado.nextLine()) > 0) {
						menu.finded_tipo_servico_success();
						System.out.println("Nome:" + tipoServico.nome);
						System.out.println("Descrição: " + tipoServico.desc);

						ArrayList<Prestador> allPrestadoresServico = tipoServico.find_prestadores();
						
						if(allPrestadoresServico.size() > 0) {

							System.out.println("Prestadores: ");
							for(int countPrestador = 0; countPrestador < allPrestadoresServico.size(); countPrestador++) {	
								menu.linha();
								System.out.println((countPrestador + 1) + " - " + allPrestadoresServico.get(countPrestador).nome);		
							}
						}
						
						menu.wait_enter();
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
				
				else if(opcaoSubMenu.equals("3")) {
					menu.linha_dupla();

					tipoServico = new TipoServico();
					
					ArrayList<TipoServico> allTiposServicos;
					try {
						allTiposServicos = tipoServico.find_all();							
						if(allTiposServicos.size() > 0) {
							
							for(int countTipoServico = 0; countTipoServico < allTiposServicos.size(); countTipoServico++) {	
								menu.linha();
								System.out.println((countTipoServico + 1) + " - " + allTiposServicos.get(countTipoServico).nome);		
							}
						}
					}
					catch(Exception e) {}
					menu.wait_enter();
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR TIPO SERVIÇO
				
				else if(opcaoSubMenu.equals("4")) {
					
					menu.cabecalho();
					System.out.print("Digite o Nome do Serviço: ");
					
					tipoServico		= new TipoServico();					
					
					if(tipoServico.find_one(teclado.nextLine()) > 0) {
						if(tipoServico.delete() > 0) {							
							menu.deleted_tipo_servico_success();
							opcaoMenu 		= teclado.nextLine();
						}
					}
					
				}
			}
			
			
			else if(opcaoMenu.equals("4")) {
				menu.menu_servico();
				opcaoSubMenu 		= teclado.nextLine();
				
				if(opcaoSubMenu.equals("1")) {
					
					servico = new Servico();
						
					menu.cabecalho();

					System.out.println("Selecione o Cliente do Serviço:");
					menu.linha_dupla();

					cliente = new Cliente();
					
					ArrayList<Pessoa> allClientes;
					try {
						allClientes = cliente.find_all();									
						if(allClientes.size() > 0) {
							
							for(int countCliente = 0; countCliente < allClientes.size(); countCliente++) {	
								menu.linha();
								System.out.println((countCliente + 1) + " - " + allClientes.get(countCliente).nome);		
							}

							menu.linha_dupla();
							System.out.print("Digite o cliente desejado: ");
							clienteEscolhido	= teclado.nextLine();
							cliente.find_one(allClientes.get(Integer.parseInt(clienteEscolhido) - 1).cpf);
							servico.cliente = cliente;
							menu.linha_dupla();
							
						}
					}
					catch(Exception e) {
						System.out.println(e);
					}

					System.out.println("Selecione o Prestador do Serviço:");
					menu.linha_dupla();
	
					prestador = new Prestador();
					
					ArrayList<Pessoa> allPrestadores;
					try {
						allPrestadores = prestador.find_all();								
							if(allPrestadores.size() > 0) {
								
								for(int countCliente = 0; countCliente < allPrestadores.size(); countCliente++) {	
									menu.linha();
									System.out.println((countCliente + 1) + " - " + allPrestadores.get(countCliente).nome);		
								}

								menu.linha_dupla();
								System.out.print("Digite o prestador desejado: ");
								clienteEscolhido	= teclado.nextLine();
								prestador.find_one(allPrestadores.get(Integer.parseInt(clienteEscolhido) - 1).cpf);
								servico.prestador  	= prestador;
								menu.linha_dupla();
								
							}
					}
					catch(Exception e) {
						System.out.println(e);
					}

					System.out.println("Selecione o Serviço Prestado:");
					menu.linha_dupla();
	
					tipoServico = new TipoServico();
					
					ArrayList<TipoServico> allServicos;
					try {
						allServicos = prestador.find_services();								
							if(allServicos.size() > 0) {
								
								for(int countServico = 0; countServico < allServicos.size(); countServico++) {	
									menu.linha();
									System.out.println((countServico + 1) + " - " + allServicos.get(countServico).nome);		
								}

								menu.linha_dupla();
								System.out.print("Digite o serviço desejado: ");
								servicoEscolhido	= teclado.nextLine();
								tipoServico.find_one(allServicos.get(Integer.parseInt(servicoEscolhido) - 1).nome);
								servico.tipoServico = tipoServico;
								menu.linha_dupla();
								
							}
					}
					catch(Exception e) {
						System.out.println(e);
					}

					System.out.print("Digite a data do serviço(dd/mm/YYYY): ");
					dataServico				= teclado.nextLine();
					servico.dataServico 	= dataServico;
					
					System.out.print("Digite o valor do serviço: ");
					valorServico 			= Double.parseDouble(teclado.nextLine());
					servico.valorServico 	= valorServico;					
					
					if(servico.save() == 1) {
						menu.register_servico_success();
						opcaoMenu 		= teclado.nextLine();
						
					}

				}
				

				
				else if(opcaoSubMenu.equals("2")) {
					menu.linha_dupla();

					servico = new Servico();
					
					ArrayList<Servico> allServicos;
					try {
						allServicos = servico.find_all();							
						if(allServicos.size() > 0) {
							
							for(int coutServicos = 0; coutServicos < allServicos.size(); coutServicos++) {	
								menu.linha();
								System.out.println(allServicos.get(coutServicos).id + " - Serviço: " + allServicos.get(coutServicos).tipoServico.nome);
								System.out.println("Cliente: " + allServicos.get(coutServicos).cliente.nome);
								System.out.println("Prestador: " + allServicos.get(coutServicos).prestador.nome);
								System.out.println("Data Serviço: " + allServicos.get(coutServicos).dataServico);
								System.out.println("Valor Serviço: " + allServicos.get(coutServicos).valorServico);
								
							}
						}
					}
					catch(Exception e) {}
					menu.wait_enter();
					opcaoMenu 		= teclado.nextLine();
				}
				
	//			DELETAR SERVIÇO
				
				else if(opcaoSubMenu.equals("3")) {
					
					menu.cabecalho();
					System.out.print("Digite o ID do Serviço: ");
					
					servico		= new Servico();					
					servico.id 	= Integer.parseInt(teclado.nextLine()); 
					
					if(servico.delete() > 0) {							
						menu.deleted_servico_success();
						opcaoMenu 		= teclado.nextLine();
					}
					
				}
			}
		
		}while(!opcaoMenu.equals("5"));
		

	}

}
