package aula1;

public class calculadora {

	public float valor_1, valor_2;
	private float soma;
	
	public float somar(float valor_1, float valor_2) {
		soma = valor_1 + valor_2;
		return soma;
	}
	
	public float soma_zera(float valor_1, float valor_2) {
		zerar_valor1();
		return valor_1 + valor_2;
	}

	private void zerar_valor1() {
		// Altera o valor de n1 para zero
		this.valor_1 = 0;
	}
	
//	public float somar(float valor_1, float valor_2) {
//		float soma;
//		soma = valor_1 + valor_2;
//		return soma;
//	}
}
