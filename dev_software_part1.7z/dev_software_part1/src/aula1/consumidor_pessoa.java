package aula1;

public class consumidor_pessoa {

	public static void main(String[] args) {
		
		pessoa professor = new pessoa();
		
		professor.cpf 		= "888";
		professor.nome 		= "Pedro";
		professor.sobrenome = "Pedro";
		
	}
}
