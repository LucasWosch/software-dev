package aula1;

public class pessoa {

	public String cpf;
	public String nome;
	public String sobrenome;
	private double salario;

	public void mostrar_nome_completo() {
		System.out.println(this.nome + this.sobrenome);
	}
	
}
