package aula1;

public class consumidor_calculadora {

	public static void main(String[] args) {
		
		calculadora calculo 	= new calculadora(); // Instancia e constroi um objeto do tipo calculadora
		calculadora calculo2 	= new calculadora();
		
		calculo.valor_1 	= 10;
		calculo.valor_2 	= 10;
		
		System.out.println(calculo.soma_zera(calculo.valor_1, calculo.valor_2));		
		System.out.println(calculo2);		
		
	}

}
